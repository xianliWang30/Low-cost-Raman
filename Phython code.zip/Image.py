from PyQt5.QtWidgets import *
from ImageProcess import Ui_MainWindow
from PyQt5.QtCore import QTimer
import sys
import numpy as np
import cv2
import datetime
import os
import matplotlib.pyplot as plt
import copy
from PyQt5.QtGui import QPixmap, QImage

class Action2(QMainWindow,Ui_MainWindow):
    # def __del__(self):
    #     pass

    img = ''

    def __init__(self):
        super().__init__()
        self.initUI()
        pass

    def initUI(self):
        self.setupUi(self)
        self.show()
        Kshape = ['MORPH_RECT', 'MORPH_ELLIPSE']
        self.comboBox_KShape.addItems(Kshape)
        Ksize = ['1x1', '3x3', '5x5', '7x7', '9x9', '11x11', '13x13', '15x15', '17x17', '19x19']
        self.comboBox_KSize.addItems(Ksize)
        self.lineEdit_Distance.setText('0.2')
        selectMode = ['All','Manual','None']
        self.comboBox_SelectMode.addItems(selectMode)

        self.Timer = QTimer()
        self.Timer.timeout.connect(self.TimerOutFun)
        self.pushButton_ImgPath.clicked.connect(self.selectPath)
        self.horizontalSlider_MinThresh.valueChanged.connect(self.changeThreshValue)
        self.horizontalSlider_MaxThresh.valueChanged.connect(self.changeThreshValue)
        self.lineEdit_MinThresh.editingFinished.connect(self.changeValue)
        self.lineEdit_MaxThresh.editingFinished.connect(self.changeValue)
        self.maxThresh = self.horizontalSlider_MaxThresh.value()
        self.minThresh = self.horizontalSlider_MinThresh.value()
        self.comboBox_KShape.currentIndexChanged.connect(self.changeKernel)
        self.comboBox_KSize.currentIndexChanged.connect(self.changeKernel)
        self.lineEdit_Distance.editingFinished.connect(self.changeKernel)
        self.pushButton_Analyze.clicked.connect(self.outCoordinate)
        self.pushButton_Output.clicked.connect(self.output)
        self.pushButton_LaserCalibration.clicked.connect(self.laserCalibration)
        # self.pushButton_Back.clicked.connect(self.close)
        self.pushButton_Back.clicked.connect(self.back)
        self.pushButton_MotorCalibration.clicked.connect(self.motorCalibration)
        self.pushButton_CalculatePulse.clicked.connect(self.calculatePulse)
        pass


    def selectPath(self):
        defaultPath = "D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache"
        ipath, ok = QFileDialog.getOpenFileName(self, "Select file", defaultPath, "(*.jpg)")
        if ok:
            imgPath = str(ipath)
            self.lineEdit_ImagePath.setText(str(imgPath))
            pass
        imgTemp = cv2.imread(imgPath)

        # self.img = cv2.cvtColor(imgTemp, cv2.COLOR_BGR2RGB)

        self.img = imgTemp
        self.x = self.img.shape[1]
        self.y = self.img.shape[0]
        self.channel = self.img.shape[2]

        imgGray = cv2.cvtColor(imgTemp, cv2.COLOR_RGB2GRAY)
        frame = QImage(imgGray, self.x, self.y, self.x, QImage.Format_Grayscale8)
        pixmap = QPixmap(frame)
        self.label_OI.setPixmap(pixmap)
        self.label_OI.setScaledContents(True) # 图片自适应
        pass

    def checkImg(self):
        if self.lineEdit_ImagePath.text() == "":
            QMessageBox.warning(self, 'No Image', 'Please select img firstly')
            return False
        else:
            return True
        pass

    def changeThreshValue(self):
        if self.checkImg() == True:
            if self.sender() == self.horizontalSlider_MinThresh:
                self.minThresh = self.horizontalSlider_MinThresh.value()
                self.lineEdit_MinThresh.setText(str(self.minThresh))
                pass
            else:
                self.maxThresh = self.horizontalSlider_MaxThresh.value()
                self.lineEdit_MaxThresh.setText(str(self.maxThresh))
                pass
            # self.x = self.img.shape[1]
            # self.y = self.img.shape[0]
            self.gray = cv2.cvtColor(self.img,cv2.COLOR_RGB2GRAY)

            # (for beads) when the sample is beads, just use the gray value, we can finish image segmentation
            _,self.thresh = (cv2.threshold(self.gray, self.minThresh, self.maxThresh, cv2.THRESH_BINARY))


            # # for cells
            # # self.gray = unevenLightCompensate(blurred, 16, 10, 255)
            # gradX = cv2.Sobel(self.gray, ddepth = cv2.CV_32F, dx = 1, dy = 0)
            # gradY = cv2.Sobel(self.gray, ddepth = cv2.CV_32F, dx = 0, dy = 1)
            # gradient = cv2.subtract(gradX, gradY)
            # gradient = cv2.convertScaleAbs(gradient) # 转换位深
            # cv2.namedWindow("Gradient", cv2.WINDOW_NORMAL)
            # cv2.imshow('Gradient', gradient)
            # blurred = cv2.GaussianBlur(gradient, (3,3), 0)
            # # blurred = gradient
            # cv2.namedWindow("blurred", cv2.WINDOW_NORMAL)
            # cv2.imshow('blurred', blurred)
            # _,self.thresh = (cv2.threshold(blurred, self.minThresh, self.maxThresh, cv2.THRESH_BINARY))

            ## for Hela cells
            # edges = cv2.Canny(self.img, self.minThresh, self.maxThresh, L2gradient=False)
            # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11, 11))  # 定义结构元素的形状和大小
            # # self.thresh = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)
            # self.thresh = edges

            ## same for both cells and beads
            frame = QImage(self.thresh, self.x, self.y, self.x, QImage.Format_Grayscale8)
            pixmap = QPixmap(frame)
            # self.label_PI.clear()
            self.label_PI.setPixmap(pixmap)
            self.label_PI.setScaledContents(True)  # 图片自适应
            pass
        pass

    def changeValue(self):
        if self.sender() == self.lineEdit_MinThresh:
            self.horizontalSlider_MinThresh.setValue(int(self.lineEdit_MinThresh.text()))
            pass
        else:
            self.horizontalSlider_MaxThresh.setValue(int(self.lineEdit_MaxThresh.text()))
            pass
        pass

    def changeKernel(self):
        distance = float(self.lineEdit_Distance.text())

        if distance >1 or distance <= 0:
            QMessageBox.warning(self,'warning','The distance must be between 0 and 1 ')
            distance, ok = QInputDialog.getDouble(self,'Please input reasonable distance!!!','Distance(0-1):')
            if ok:
                self.lineEdit_Distance.setText(str(distance))
                pass
            pass

        KshapeTemp = self.comboBox_KShape.currentText()
        if KshapeTemp == "MORPH_ELLIPSE":
            Kshape = cv2.MORPH_ELLIPSE
            pass
        elif KshapeTemp == "MORPH_RECT":
            Kshape = cv2.MORPH_RECT
            pass

        KsizeTemp = self.comboBox_KSize.currentText()

        if KsizeTemp == "1x1":
            Ksize = (1, 1)
            pass
        elif KsizeTemp == "3x3":
            Ksize = (3, 3)
            pass
        elif KsizeTemp == "5x5":
            Ksize = (5, 5)
            pass
        elif KsizeTemp == "7x7":
            Ksize = (7, 7)
            pass
        elif KsizeTemp == "9x9":
            Ksize = (9, 9)
            pass
        elif KsizeTemp == "11x11":
            Ksize = (11, 11)
            pass
        elif KsizeTemp == "13x13":
            Ksize = (13, 13)
            pass
        elif KsizeTemp == "15x15":
            Ksize = (15, 15)
            pass
        elif KsizeTemp == "17x17":
            Ksize = (17, 17)
            pass
        elif KsizeTemp == "19x19":
            Ksize = (19, 19)
            pass

        kernel = cv2.getStructuringElement(Kshape, Ksize)  # 定义矩形结构元素
        opening = cv2.morphologyEx(self.thresh, cv2.MORPH_GRADIENT, kernel)  # 梯度
        # sure_bg = cv2.dilate(opening, kernel, iterations=10)

        # Finding sure foreground area
        dist_transform = cv2.distanceTransform(opening, cv2.DIST_L2, 5)
        ret, sure_fg = cv2.threshold(dist_transform, distance * dist_transform.max(), 255, 0)
        self.sure_fg = np.uint8(sure_fg)

        img2 = self.img.copy()
        # print(id(self.img))
        # print(id(img2))
        img2[self.sure_fg == 255] = [255, 0, 0]
        # frame = QImage(img2, self.x, self.y, self.channel*self.x, QImage.Format_Grayscale16)
        frame = QImage(self.sure_fg, self.x, self.y, self.x, QImage.Format_Grayscale8)

        pixmap = QPixmap(frame)
        self.label_PI2.clear()
        self.label_PI2.setPixmap(pixmap)
        self.label_PI2.setScaledContents(True)  # 图片自适应

        pass

    def outCoordinate(self):
        # 这里需要注意，不同的opencv版本，输出参数的个数不同
        _, contours, hirearchy = cv2.findContours(self.sure_fg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)  # 找出连通域
        area = []  # 建立空数组，放连通域面积
        contours1 = []  # 建立空数组，放减去最小面积的数
        for i in contours:
            if cv2.contourArea(i) > 5:  # 计算面积 去除面积小的 连通域
                contours1.append(i)
        # print(len(contours1) - 1)  # 计算连通域个数
        draw = cv2.drawContours(self.img, contours1, -1, (0, 255, 0), 2)  # 描绘连通域求连通域重心 以及 在重心坐标点描绘数字
        self.grayCenter = []
        self.area = []
        for i, j in zip(contours1, range(len(contours1))):
            M = cv2.moments(i)
            cX = (M["m10"] / M["m00"])
            cY = (M["m01"] / M["m00"])
            self.grayCenter.append([cX, cY])
            self.area.append(cv2.contourArea(i))
            cX1 = int(cX)
            cY1 = int(cY)
            draw1 = cv2.putText(draw, str(j), (cX1, cY1), 1, 1, (255, 0, 255), 1)  # 在中心坐标点上描绘数字展示图片
            pass
        # print('grayCenter:{}, shape:{}'.format(self.grayCenter,np.shape(self.grayCenter)))
        cv2.namedWindow("Gray center",cv2.WINDOW_NORMAL)
        cv2.imshow("Gray center", draw1)
        cv2.waitKey()

        # cv2.destroyWindow()
        pass

    def output(self):
        curr_time = datetime.datetime.now()
        time_str = datetime.datetime.strftime(curr_time, '%Y_%m_%d_%H_%M_%S')
        # filename = str(time_str) + '.txt'
        filename = 'Points need to be acquired' + '.txt'
        savePath = 'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate'
        self.position = []
        self.position1 = []
        self.idd = []
        self.area1 = []
        if self.comboBox_SelectMode.currentText() == "None":
            QMessageBox.information(self, 'Information', 'You do not select any point')
            pass

        elif self.comboBox_SelectMode.currentText() == "All":
            os.chdir(savePath)
            self.position1 = self.grayCenter
            self.position.append(self.position1[0])
            for i in range(1, len(self.position1)):
                temp = self.position1[i-1]
                x = self.position1[i]
                self.position.append([temp[0] - x[0], temp[1] - x[1]])
                pass
            for i in range(len(self.position1)):
                self.idd.append(i)
                self.area1.append(self.area[i])
            pass
            # self.position[:] = [[temp[0] - x[0], temp[1] - x[1]] for x in self.position]
            # self.position[0] = temp
            np.savetxt(filename, self.position)
            np.savetxt('Points need to be acquired(abs).txt', self.position1)
            pass

        else:
            points, ok = QInputDialog.getText(self, 'Select point', 'Please select point you want to measure:')
            point_list = points.split(',')
            if ok:
                self.lineEdit_SelectPoint.setText(points)
                for i in point_list:
                    self.position1.append(self.grayCenter[int(i)])
                    self.idd.append(int(i))
                    self.area1.append(self.area[int(i)])
                    pass
                self.position.append(self.position1[0])
                for i in range(1, len(self.position1)):
                    # print('i is :{}'.format(i))
                    temp = self.position1[i - 1]
                    # print('temp is :{}'.format(temp))
                    x = self.position1[i]
                    # print('x is :{}'.format(x))
                    self.position.append([temp[0] - x[0], temp[1] - x[1]])

                    pass

                # temp = self.position1[0]
                # print(1)
                # temp1 = np.diff(self.position1)
                # temp1 = temp1.tolist()
                # print(2)
                # self.position = [temp, temp1[0]]
                # self.position[:] = [[temp[0] - x[0], temp[1] - x[1]] for x in self.position]
                # self.position[0] = temp
                os.chdir(savePath)
                np.savetxt(filename, self.position)
                np.savetxt('Points need to be acquired(abs).txt', self.position1)
                np.savetxt('idd.txt', self.idd)
                np.savetxt('area.txt', self.area1)
                pass
            else:
                QMessageBox.warning(self,'Warning','You do not select any point!!!!')
                pass
            # QMessageBox.information(self,'Select point','Please select point you want to measure:')
            pass
        # print(self.position)
        pass

    def laserCalibration(self):
        laser_Path = "D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\LaserCalibration"
        ipath, ok = QFileDialog.getOpenFileName(self, "Select file", laser_Path, "(*.jpg)")
        os.chdir(laser_Path)
        if ok:
            imgPath = str(ipath)
            pass
        imgTemp = cv2.imread(imgPath)

        # cv2.namedWindow('JPG',cv2.WINDOW_NORMAL)
        # cv2.imshow('JPG', imgTemp)
        # cv2.waitKey(2)

        laserGray = cv2.cvtColor(imgTemp, cv2.COLOR_RGB2GRAY)
        # cv2.namedWindow('Gray',cv2.WINDOW_NORMAL)
        # cv2.imshow('Gray',laserGray)
        # cv2.waitKey(2)

        _, thresh = cv2.threshold(laserGray, 185, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
        # cv2.namedWindow('thresh', cv2.WINDOW_NORMAL)
        # cv2.imshow('thresh', thresh)
        # cv2.waitKey(2)

        # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))  # 定义矩形结构元素
        # opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)  # 梯度
        # dist_transform = cv2.distanceTransform(opening, cv2.DIST_L2, 5)
        # ret, sure_fg = cv2.threshold(dist_transform, 0.20 * dist_transform.max(), 255, 0)
        # sure_fg = np.uint8(sure_fg)
        # cv2.namedWindow('sure_fg', cv2.WINDOW_NORMAL)
        # cv2.imshow('sure_fg', sure_fg)
        # cv2.waitKey()

        _, contours, hirearchy = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)  # 找出连通域
        M = cv2.moments(contours[0])
        print(1)
        self.XLaser = int(M["m10"] / M["m00"])
        self.YLaser = int(M["m01"] / M["m00"])
        print(self.XLaser)
        self.lineEdit_Position.setText(str(self.XLaser))
        self.lineEdit_Position_2.setText(str(self.YLaser))
        np.savetxt('LaserPosition.txt', [self.XLaser, self.YLaser])
        pass

    def motorCalibration(self):
        # x direction
        os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\MotorCalibration')
        img4MotorCalibration = cv2.imread('1.JPG')
        img4MotorCalibration2 = cv2.imread('2.JPG')
        img4MotorCalibration3 = cv2.imread('3.JPG')
        img4MotorCalibration4 = cv2.imread('4.JPG')

        position1 = imgProcess(img4MotorCalibration)
        position2 = imgProcess(img4MotorCalibration2)
        position3 = imgProcess(img4MotorCalibration3)
        position4 = imgProcess(img4MotorCalibration4)

        x = [0, (position1[1]-position2[1]), (position1[1]-position3[1]), (position1[1]-position4[1])]
        x = abs(np.array(x))

        y = [0, 200, 400, 600]
        y = np.array(y)
        f1 = np.polyfit(x, y, 1)
        fx = np.poly1d(f1)
        plt.figure(1)
        plt.subplot(2, 1, 1)
        plt.scatter(x, y)
        plt.plot(x, fx(x))


        print(f1[0], f1[1])
        self.slopeMotor = (f1[0])
        self.interceptMotor = (f1[1])
        self.lineEdit_Slope.setText(str((f1[0])))
        self.lineEdit_Intercept.setText(str((f1[1])))
        np.savetxt('Relationship between pulse and Image length.txt', [f1[0], f1[1]])

        # y direction
        img4MotorCalibration = cv2.imread('y1.JPG')
        img4MotorCalibration2 = cv2.imread('y2.JPG')
        img4MotorCalibration3 = cv2.imread('y3.JPG')
        img4MotorCalibration4 = cv2.imread('y4.JPG')

        position1 = imgProcess(img4MotorCalibration)
        position2 = imgProcess(img4MotorCalibration2)
        position3 = imgProcess(img4MotorCalibration3)
        position4 = imgProcess(img4MotorCalibration4)

        x = [0, (position1[0] - position2[0]), (position1[0] - position3[0]), (position1[0] - position4[0])]
        x = abs(np.array(x))

        y = [0, 200, 400, 600]
        y = np.array(y)
        f1 = np.polyfit(x, y, 1)
        fx = np.poly1d(f1)
        plt.figure(1)
        plt.subplot(2,1,2)
        plt.scatter(x, y)
        plt.plot(x, fx(x))
        plt.show()

        self.slopeMotorY = (f1[0])
        self.interceptMotorY = (f1[1])
        self.lineEdit_Slope.setText(str((f1[0])))
        self.lineEdit_Intercept.setText(str((f1[1])))
        # print(f1[0],f1[1])
        np.savetxt('Relationship between pulse and Image length Y.txt', [f1[0], f1[1]])

        pass

    def calculatePulse(self):
        savePath = 'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate'
        motorPulse = []
        motorPulse1 = []
        timeflag = 0
        os.chdir(savePath)
        with open('Points need to be acquired.txt', 'r') as f:
            position = f.readline()
            while position:
                x_tmp, y_tmp = [float(i) for i in position.split()]
                if timeflag == 0:
                    Diff_temp = [-(x_tmp - self.XLaser), -(y_tmp - self.YLaser)]
                else:
                    Diff_temp = [x_tmp, y_tmp]
                    pass
                timeflag += 1
                positionDiff = [int(Diff_temp[0]*self.slopeMotorY+self.interceptMotorY), int(Diff_temp[1]*self.slopeMotor+self.interceptMotor)]
                # slopeMotor = int(self.lineEdit_Slope.text())
                # interceptMotor = int(self.lineEdit_Intercept.text())
                motorPulse.append(positionDiff)
                position = f.readline()
                pass

            # temp = motorPulse[0]
            # motorPulse1[:] = [[temp[0]-x[0], temp[1]-x[1]] for x in motorPulse]
            # motorPulse1[0] = temp
            print(motorPulse)
            # print(motorPulse1)

            pass
        np.savetxt('MotorPulse.txt', motorPulse)
        pass

    def TimerOutFun(self):
        pass

    def back(self):
        threshold = self.lineEdit_MinThresh.text()
        kernalShape = self.comboBox_KShape.currentText()
        kernalSize = self.comboBox_KSize.currentText()
        distance = self.lineEdit_Distance.text()

        imgParam = {"threshold": threshold,
                    "kernalShape": kernalShape,
                    "kernalSize": kernalSize,
                    "distance": distance}
        print(imgParam, type(imgParam))
        os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
        # np.savetxt('imgparam.txt', str(imgParam))
        f = open('imgparam.txt', 'w')
        f.write(str(imgParam))
        # Ui_MainWindow.close()
        self.close()
        pass
    pass

def imgProcess(img):
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    _, thresh = (cv2.threshold(gray, 190, 255, cv2.THRESH_BINARY))

    cv2.namedWindow('thresh', cv2.WINDOW_NORMAL)
    cv2.imshow("thresh", thresh)

    Kshape = cv2.MORPH_ELLIPSE
    Ksize = (3, 3)
    kernel = cv2.getStructuringElement(Kshape, Ksize)  # 定义矩形结构元素
    opening = cv2.morphologyEx(thresh, cv2.MORPH_GRADIENT, kernel)  # 梯度
    # Finding sure foreground area
    dist_transform = cv2.distanceTransform(opening, cv2.DIST_L2, 5)
    ret, sure_fg = cv2.threshold(dist_transform, 0.2 * dist_transform.max(), 255, 0)

    # cv2.imshow('sure_fg',sure_fg)
    # cv2.waitKey(2)

    sure_fg = np.uint8(sure_fg)
    _, contours, hirearchy = cv2.findContours(sure_fg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)  # 找出连通域
    contours1 = []  # 建立空数组，放减去最小面积的数
    for i in contours:
        if cv2.contourArea(i) > 3:  # 计算面积 去除面积小的 连通域
            contours1.append(i)
    # print(len(contours1) - 1)  # 计算连通域个数
    draw = cv2.drawContours(img, contours1, -1, (0, 255, 0), 2)  # 描绘连通域求连通域重心 以及 在重心坐标点描绘数字
    grayCenter = []
    for i, j in zip(contours1, range(len(contours1))):
        M = cv2.moments(i)
        cX = int(M["m10"] / M["m00"])
        cY = int(M["m01"] / M["m00"])
        grayCenter.append([cX, cY])
        draw1 = cv2.putText(draw, str(j), (cX, cY), 1, 1, (255, 0, 255), 1)  # 在中心坐标点上描绘数字展示图片
        pass

    # cv2.namedWindow('Gray center', cv2.WINDOW_NORMAL)
    # cv2.imshow("Gray center", draw1)
    # cv2.waitKey()
    return [cX, cY]


def unevenLightCompensate(img, blockSize, min_num,max_num):
    gray = img
    average = np.mean(gray)

    rows_new = int(np.ceil(gray.shape[0] / blockSize))
    cols_new = int(np.ceil(gray.shape[1] / blockSize))

    blockImage = np.zeros((rows_new, cols_new), dtype=np.float32)
    for r in range(rows_new):
        for c in range(cols_new):
            rowmin = r * blockSize
            rowmax = (r + 1) * blockSize
            if (rowmax > gray.shape[0]):
                rowmax = gray.shape[0]
            colmin = c * blockSize
            colmax = (c + 1) * blockSize
            if (colmax > gray.shape[1]):
                colmax = gray.shape[1]

            imageROI = gray[rowmin:rowmax, colmin:colmax]
            temaver = np.mean(imageROI)
            blockImage[r, c] = temaver
    blockImage = blockImage - average
    blockImage2 = cv2.resize(blockImage, (gray.shape[1], gray.shape[0]), interpolation=cv2.INTER_CUBIC)
    # blockImage2[200:800,200:500]=0
    gray2 = gray.astype(np.float32)
    dst = gray2 - blockImage2
    for i in range(len(dst)):
        for j in range(len(dst[0])):
            if dst[i][j]<min_num:
                dst[i][j]=min_num
            elif dst[i][j]>max_num:
                dst[i][j]=max_num
    dst = dst.astype(np.uint8)
    dst = cv2.GaussianBlur(dst, (3, 3), 0)
    return dst


if __name__ == '__main__':
    app = QApplication(sys.argv)
    action = Action2()
    sys.exit(app.exec_())
    pass
