from PyQt5.QtWidgets import *
from PyQt5.QtGui import QPixmap, QImage, QPainter , QPen, QTransform
from PyQt5.QtCore import QTimer, QRect, Qt,QCoreApplication,QThread
from PyQt5.QtCore import *
from cameraPartUI2 import Ui_MainWindow
from Image import Action2
# from AutoAcquire import Action3
from Autofocus_sketch import Brenner_gradient, Lorentz_fitting
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
# from win32process import SuspendThread, ResumeThread
import serial
import serial.tools.list_ports
import zwoasi as asi
from PIL import Image
import numpy as np
import sys
import os
import argparse
import cv2
import time
from tkinter import filedialog
import mvsdk
import platform
import datetime

global working
working = False

global working2
working2 = False

global workingPositioning
workingPositioning = False

global autoAcqFlag
autoAcqFlag = True

global stopAutoAcqFlag
stopAutoAcqFlag = False

global FinishedAutofocusFlag
FinishedAutofocusFlag = False

def save_control_values(filename, settings):
    filename += '.txt'
    with open(filename, 'w') as f:
        for k in sorted(settings.keys()):
            f.write('%s: %s\n' % (k, str(settings[k])))
            pass
    print('Camera settings saved to %s' % filename)
    pass

def check_environment():
    env_filename = os.getenv('ZWO_ASI_LIB')

    parser = argparse.ArgumentParser(description='Process and save images from a camera')
    parser.add_argument('filename',
                        nargs='?',
                        help='SDK library filename')
    args = parser.parse_args()

    # Initialize zwoasi with the name of the SDK library
    if args.filename:
        asi.init(args.filename)
        pass
    elif env_filename:
        asi.init(env_filename)
        pass
    else:
        print('The filename of the SDK library is required (or set ZWO_ASI_LIB environment variable with the filename)')
        sys.exit(1)
        pass
    pass

class ImageAcqThread(QThread):
    global working
    global timeInter1

    _signal = pyqtSignal(np.ndarray)
    def __init__(self,argument_):
        super().__init__()
        self.working = True
        self.fun = argument_
        pass
    def __del__(self):
        self.working = False
        # self.wait()
        pass
    def run(self):
        while working:
            img = self.fun.capture()
            self._signal.emit(img)
            time.sleep(timeInter1)
            pass
        pass
    pass

class TestPositioning(QThread):
    _signal = pyqtSignal(int)

    def __init__(self,argument_):
        super().__init__()
        self.serialMove = SerialPort()
        self.workingPositioning = True
        self.hcamera = argument_[0]
        self.ser = argument_[1]
        self.currentframe = 0
        self.directionFlag = True
        pass

    def __del__(self):
        self.workingPositioning = False
        # self.wait()
        pass
    def run(self):
        global workingPositioning
        while workingPositioning:
            global focusingFlag
            if focusingFlag:
                print('Autofocusing!!!!')
            else:
                if self.directionFlag:
                    frame = GetMVFrame(self.hcamera)
                    filename = '0,' + str(self.currentframe)+'.jpg'
                    mode = None
                    image = Image.fromarray(frame, mode=mode)
                    image.save(filename)

                    self.serialMove.movement(self.ser, 'X Axis', 800)
                    # self.serialMove.movement(self.ser, 'Y Axis', 800)

                    time.sleep(2.5)
                    # x = frame.shape[1]
                    # y = frame.shape[0]
                    # Qframe = QImage(frame, x, y, x, QImage.Format_Grayscale8)
                    # pixmap = QPixmap(Qframe)
                    # self.Viewer2.setPixmap(pixmap)
                    # self.Viewer2.setScaledContents(True)  # 图片自适应
                    self._signal.emit(1)
                    focusingFlag = True
                    self.directionFlag = False
                else:
                    frame = GetMVFrame(self.hcamera)
                    filename = '1,' + str(self.currentframe)+'.jpg'
                    mode = None
                    image = Image.fromarray(frame, mode=mode)
                    image.save(filename)

                    self.serialMove.movement(self.ser, 'X Axis', -800)
                    # self.serialMove.movement(self.ser, 'Y Axis', -800)

                    time.sleep(2.5)
                    # x = frame.shape[1]
                    # y = frame.shape[0]
                    # Qframe = QImage(frame, x, y, x, QImage.Format_Grayscale8)
                    # pixmap = QPixmap(Qframe)
                    # self.Viewer2.setPixmap(pixmap)
                    # self.Viewer2.setScaledContents(True)  # 图片自适应
                    self._signal.emit(1)
                    focusingFlag = True
                    self.currentframe += 1
                    self.directionFlag = True
                    pass

                if self.currentframe == 200:
                    workingPositioning = False
                    pass
                time.sleep(0.51)
            pass
        pass
    pass

class ImageAcqThread2(QThread):
    global working2
    global timeInter2
    _signal = pyqtSignal(np.ndarray)

    def __init__(self,argument_):
        super().__init__()
        self.working2 = True
        self.fun = argument_
        pass

    def __del__(self):
        self.working2 = False
        # self.wait()
        pass

    def run(self):
        while working2:
            # cap = mvsdk.CameraGetCapability(self.fun)
            # # 计算RGB buffer所需的大小，这里直接按照相机的最大分辨率来分配
            # FrameBufferSize = cap.sResolutionRange.iWidthMax * cap.sResolutionRange.iHeightMax * 1
            #
            # # 分配RGB buffer，用来存放ISP输出的图像
            # # 备注：从相机传输到PC端的是RAW数据，在PC端通过软件ISP转为RGB数据（如果是黑白相机就不需要转换格式，但是ISP还有其它处理，所以也需要分配这个buffer）
            # pFrameBuffer = mvsdk.CameraAlignMalloc(FrameBufferSize, 16)
            #
            # pRawData, FrameHead = mvsdk.CameraGetImageBuffer(self.fun, 2000)
            # mvsdk.CameraImageProcess(self.fun, pRawData, pFrameBuffer, FrameHead)
            # mvsdk.CameraReleaseImageBuffer(self.fun, pRawData)
            #
            # # windows下取到的图像数据是上下颠倒的，以BMP格式存放。转换成opencv则需要上下翻转成正的
            # # linux下直接输出正的，不需要上下翻转
            # if platform.system() == "Windows":
            #     mvsdk.CameraFlipFrameBuffer(pFrameBuffer, FrameHead, 1)
            #
            # # 此时图片已经存储在pFrameBuffer中，对于彩色相机pFrameBuffer=RGB数据，黑白相机pFrameBuffer=8位灰度数据
            # # 把pFrameBuffer转换成opencv的图像格式以进行后续算法处理
            # frame_data = (mvsdk.c_ubyte * FrameHead.uBytes).from_address(pFrameBuffer)
            # frame = np.frombuffer(frame_data, dtype=np.uint8)
            #
            # frame = frame.reshape((FrameHead.iHeight, FrameHead.iWidth))
            frame = GetMVFrame(self.fun)
            self._signal.emit(frame)
            time.sleep(timeInter2)
            pass
        pass
    pass

class AutoFocusThread(QThread):

    _signal = pyqtSignal(np.ndarray)
    AutoFocusWorking = True

    def __init__(self, argument_):
        super().__init__()
        global focusingFlag
        focusingFlag = True
        global FinishedAutofocusFlag
        FinishedAutofocusFlag = False
        self.Bren = []
        self.BrenFore = []
        self.BrenBack = []
        self.motor = SerialPort()
        self.hCamera = argument_[0]
        self.ser = argument_[1]
        self.LineFigure = argument_[2]
        self.ImgNums = argument_[3]
        self.Steps = argument_[4]
        self.thread2 = argument_[5]
        # self.steps_tuple = argument_[3]
        self.numflag = 0
        self.SecondFoFlag = False
        global steps_tuple
        self.motor.movement(self.ser, 'Z Axis', steps_tuple[0])
        time.sleep(1.5)
        pass

    def __del__(self):
        # global AutoFocusWorking
        self.AutoFocusWorking = False
        # self.wait()
        pass

    def run(self):
        # We can click "Quit Acquisition" Button which would chaneg the gobal varible "autoAcqFlag" to end current porcess
        global autoAcqFlag
        global stopAutoAcqFlag
        while self.AutoFocusWorking and autoAcqFlag:
            # print(self.AutoFocusWorking)
            frame = GetMVFrame(self.hCamera)
            frame = unevenLightCompensate(frame, 11, 0, 255)
            frame = gamma_trans(frame, 1.35)
            temp1 = Brenner_gradient(frame)
            self.Bren.append(temp1)

            if (self.numflag == self.ImgNums - 1) and not self.SecondFoFlag:
                # print("first")
                # print(self.SecondFoFlag)

                # self.focusFlag = False

                zPos = list(range((-self.ImgNums + 1) * self.Steps, self.Steps, self.Steps))
                # print(zPos)
                # self.Bren1 = self.Bren[1:]
                max_temp = max(self.Bren)
                self.Bren1 = [x/max_temp*1000 for x in self.Bren]

                # print("zPos is:{} and Bren1 is{}:".format(zPos[:], self.Bren1[:]))
                mu, curvex, yvals = Lorentz_fitting(zPos, self.Bren1)
                mu = int(mu)
                # if (mu) >= 1500:
                #     mu = 200
                #     pass
                # if (mu) <= -1500:
                #     mu = -200
                #     pass

                if (mu) >= 800:
                    mu = 400
                    pass
                if (mu) <= -800:
                    mu = -400
                    pass

                # self.line = Line2D(curvex, yvals)
                self.x = zPos
                self.y = self.Bren1
                self.focusPos = mu
                self.xfitting = curvex
                self.yfitting = yvals
                self.LineFigure.ax.clear()
                self.LineFigure.plotfitting(self.x, self.y, self.xfitting, self.yfitting)
                self.LineFigure.draw()
                # self.movement(self.focusPos, 'Z Axis')
                self.motor.movement(self.ser, 'Z Axis', self.focusPos)
                time.sleep(3)

                self.SecondFoFlag = True
                self.exitFlag = True
                self.oriNum = 0
                self.Brentemp = []
                frame = GetMVFrame(self.hCamera)
                # frame = unevenLightCompensate(frame, 12, 0, 255)
                self.temp11 = Brenner_gradient(frame)
                pass

            elif(self.numflag < self.ImgNums - 1) and not self.SecondFoFlag:
                self.numflag += 1
                global steps_tuple
                self.motor.movement(self.ser, 'Z Axis', steps_tuple[self.numflag])
                time.sleep(0.3)
                pass
                pass


            if self.SecondFoFlag:

                ydiff = np.diff(self.yfitting)
                # when we acquire beads data, enbale this flag
                # sgnflag = ydiff[5] * ydiff[95]
                # when we acquire cell data, we don't enable this flag to avoid the mistake
                sgnflag = -1

                if sgnflag <= 0:
                    # do nothing to save time

                    self.AutoFocusWorking = False
                    self.SecondFoFlag = False
                    self.oriNum = 0
                    global focusingFlag
                    focusingFlag = False
                    global FinishedAutofocusFlag
                    FinishedAutofocusFlag = True
                    # global working2
                    # working2 = True
                    # self.thread2.start()
                    pass

                    # steps1 = 13 * [20]
                    # steps1[0] = -130
                    # zPos = list(range((-12) * 20, 20, 20))
                    # if self.oriNum < len(steps1):
                    #     self.motor.movement(self.ser, 'Z Axis', steps1[self.oriNum])
                    #     time.sleep(0.55)
                    #     frame = GetMVFrame(self.hCamera)
                    #     # frame = unevenLightCompensate(frame, 12, 0, 255)
                    #     temp1 = Brenner_gradient(frame)
                    #     self.Brentemp.append(temp1)
                    #     self.oriNum += 1
                    #     # print(self.oriNum)
                    # else:
                    #     # print('zPos and Brentemp are:{}'.format(zPos[1:], self.Brentemp[1:]))
                    #     mu, curvex, yvals = Lorentz_fitting(zPos[1:], self.Brentemp[1:])
                    #     mu = int(mu)
                    #     self.motor.movement(self.ser, 'Z Axis', mu)
                    #     time.sleep(1.3)
                    #     self.AutoFocusWorking = False
                    #     self.SecondFoFlag = False
                    #     self.oriNum = 0
                    #     global focusingFlag
                    #     focusingFlag = False
                    #
                    #     global FinishedAutofocusFlag
                    #     FinishedAutofocusFlag = True
                    #     #
                    #     self.LineFigure.ax.clear()
                    #     self.LineFigure.plotfitting(zPos[1:], self.Brentemp[1:], curvex, yvals)
                    #     self.LineFigure.draw()
                    #     # self._finishedAutofocus.emit()
                    #     global working2
                    #     working2 = True
                    #     self.thread2.start()
                    #     pass

                    pass

                if sgnflag > 0:
                    if ydiff[50] > 0:
                        # temp1 = Brenner_gradient(self.frame)
                        if self.oriNum < 100 and self.exitFlag:
                            self.motor.movement(self.ser, 'Z Axis', 30)
                            time.sleep(0.3)
                            frame = GetMVFrame(self.hCamera)
                            temp1 = Brenner_gradient(frame)
                            self.BrenFore.append(temp1)
                            self.oriNum += 1

                            if temp1 > self.temp11:
                                self.temp11 = temp1
                                pass

                            elif temp1 * 1.05 < self.temp11:
                                self.exitFlag = False
                                self.motor.movement(self.ser, 'Z Axis', -30)
                                time.sleep(0.3)
                                self.oriNum = 0

                                # global focusingFlag
                                focusingFlag = False
                                # global FinishedAutofocusFlag
                                FinishedAutofocusFlag = True
                                self.AutoFocusWorking = False
                                self.SecondFoFlag = False
                                # working2 = True
                                # self.thread2.start()
                                pass

                            else:
                                self.motor.movement(self.ser, 'Z Axis', 30)
                                time.sleep(0.3)
                                pass
                            pass

                        else:
                            self.exitFlag = False
                            focusingFlag = False
                            FinishedAutofocusFlag = True
                            self.AutoFocusWorking = False
                            self.SecondFoFlag = False
                            # working2 = True
                            # self.thread2.start()
                            pass
                        pass

                    if ydiff[50] < 0:

                        if self.oriNum < 100 and self.exitFlag:

                            self.motor.movement(self.ser, 'Z Axis', -30)
                            time.sleep(0.5)
                            frame = GetMVFrame(self.hCamera)
                            # frame = unevenLightCompensate(frame, 12, 0, 255)

                            temp1 = Brenner_gradient(frame)
                            self.BrenFore.append(temp1)
                            self.oriNum += 1

                            if temp1 > self.temp11:
                                # self.moveBackward2(30)
                                self.temp11 = temp1
                                pass

                            elif temp1 * 1.05 < self.temp11:
                                self.exitFlag = False
                                self.motor.movement(self.ser, 'Z Axis', 30)
                                time.sleep(0.5)
                                self.oriNum = 0

                                # global focusingFlag
                                focusingFlag = False
                                # global FinishedAutofocusFlag
                                FinishedAutofocusFlag = True
                                self.AutoFocusWorking = False
                                self.SecondFoFlag = False
                                # working2 = True
                                # self.thread2.start()
                                pass

                            else:
                                self.motor.movement(self.ser, 'Z Axis', -30)
                                time.sleep(0.5)
                                pass
                            pass

                        else:
                            self.exitFlag = False
                            focusingFlag = False
                            FinishedAutofocusFlag = True
                            self.AutoFocusWorking = False
                            self.SecondFoFlag = False
                            # working2 = True
                            # self.thread2.start()
                            pass
                        pass
                    pass
                # print('self.SecondFoFlag is:{}'.format(self.SecondFoFlag))

                pass

            time.sleep(0.51)
            # self._signal.emit(frame)
            pass # for while

        pass

    pass

# for beads
class AutoAcquisitionThread(QThread):
    AutoAcqWorking = True
    _signal = pyqtSignal(int)
    _RamanSignal = pyqtSignal(np.ndarray)
    sleepTimeInterval = 0.5
    def __init__(self, argument_):
        super().__init__()
        # print('Thread Init')
        # self.fun = argument_
        self.serialMove = SerialPort()
        self.Imgprocessor = ImgProcess()
        self.FishedRamanacquiredFlag = False
        self.currentframe = 0
        self.cycleIndex = 1
        self.AcqNums = 0

        self.TotalNum = argument_[0]
        self.hcamera = argument_[1]
        self.camera = argument_[2]
        self.Viewer = argument_[3]
        self.Viewer2 = argument_[4]
        self.ser = argument_[5]
        self.curve = argument_[6]
        self.lineEdit_CurrentFrame = argument_[7]
        self.xPosition = argument_[8]
        self.img1 = argument_[9]
        self.xPositionAbs = argument_[10]
        self.yPositionAbs = argument_[11]
        self.xLaserPosition = argument_[12]
        self.yLaserPosition = argument_[13]
        self.fittingSlope = argument_[14]
        self.fittingIntercept = argument_[15]
        self.fittingSlopeY = argument_[16]
        self.fittingInterceptY = argument_[17]
        self.xPulse = argument_[18]
        self.yPulse = argument_[19]
        self.w = argument_[20]
        self.h = argument_[21]
        self.sleepPeriod = argument_[22]
        self.sampleId = argument_[23]
        self.area = argument_[24]

        self.xWay, self.yWay = 0, 0
        self.xWayNum, self.yWayNum = 0, 0
        global FinishedAutofocusFlag
        FinishedAutofocusFlag = False

        self.xStep = 800
        self.yStep = -800
        # # Block Laser
        # self.serialMove.ServoMovement(self.ser, -1)
        # time.sleep(0.5)
        # # Turn on LED
        # self.serialMove.changevoltage(self.ser, 1)
        # time.sleep(0.1)
        #
        # self.serialMove.movement(self.ser, 'X Axis', self.yPulse[0])
        # time.sleep(2)
        # self.serialMove.movement(self.ser, 'Y Axis', self.xPulse[0])
        # time.sleep(2)
        curr_time = datetime.datetime.now()
        time_str = datetime.datetime.strftime(curr_time, '%Y_%m_%d_%H_%M_%S')
        self.filename1 = 'Object_id' + str(time_str) + '.txt'
        self.filename2 = 'Object_area'+ str(time_str) + '.txt'
        # self.filename1 = str(self.savedNum) + '_' + time_str + '.txt'
        pass

    def __del__(self):
        self.working = False
        # self.wait()
        pass

    def timeInterval(self, pulse):
        if pulse <= 50:
            self.sleepTimeInterval = 0.3
            pass
        elif pulse <= 100:
            self.sleepTimeInterval = 0.55
            pass
        elif pulse > 100 and pulse >= 600:
            self.sleepTimeInterval = 0.55 + int(round(pulse/100)) * 0.3
            pass
        elif pulse <= 1500:
            self.sleepTimeInterval = 3
            pass
        elif pulse <= 2000:
            self.sleepTimeInterval = 4
            pass
        elif pulse <= 3000:
            self.sleepTimeInterval = 5
            pass
        else:
            self.sleepTimeInterval = 8
            pass
        return self.sleepTimeInterval

    def run(self):
        # We can click "Quit Acquisition" Button which would chaneg the gobal varible "autoAcqFlag" to end current porcess
        while self.AutoAcqWorking and autoAcqFlag:
            frame = GetMVFrame(self.hcamera)
            x = frame.shape[1]
            y = frame.shape[0]
            Qframe = QImage(frame, x, y, x, QImage.Format_Grayscale8)
            pixmap = QPixmap(Qframe)
            self.Viewer2.setPixmap(pixmap)
            self.Viewer2.setScaledContents(True)  # 图片自适应

            if self.currentframe < self.TotalNum:
                # if we clicked "Stop acquisition" button we will stop current acquisition!!!
                global stopAutoAcqFlag
                if not stopAutoAcqFlag:
                    # judge whether it is in autofocus state
                    global focusingFlag
                    if focusingFlag:
                        print('Autofocusing!!!')
                        # print("focusingFlag is :{}".format(focusingFlag))
                        # frame = GetMVFrame(self.hcamera)
                        # x = frame.shape[1]
                        # y = frame.shape[0]
                        # Qframe = QImage(frame, x, y, x, QImage.Format_Grayscale8)
                        # pixmap = QPixmap(Qframe)
                        # self.Viewer2.setPixmap(pixmap)
                        # self.Viewer2.setScaledContents(True)  # 图片自适应
                        pass

                    else:
                        # frame = GetMVFrame(self.hcamera)
                        # x = frame.shape[1]
                        # y = frame.shape[0]
                        # Qframe = QImage(frame, x, y, x, QImage.Format_Grayscale8)
                        # pixmap = QPixmap(Qframe)
                        # self.Viewer2.setPixmap(pixmap)
                        # self.Viewer2.setScaledContents(True)  # 图片自适应

                        # print('Finished Autofocusing')
                        # judge whether finished data acquisition in one frame
                        global FinishedAutofocusFlag
                        if FinishedAutofocusFlag:
                            # 图相处理，添加更新位置坐标，以及脉冲的数量的txt文件
                            self.img1 = GetMVFrame(self.hcamera)
                            self.img3 = self.img1.copy()
                            self.Imgprocessor.imgSegment(self.img3, 200, cv2.MORPH_ELLIPSE, (3, 3), 0.2, self.w, self.h)
                            time.sleep(0.1)
                            # self.imageTracingFlag = True
                            self.AcqNums = 0
                            self.xPosition = []
                            self.yPosition = []
                            self.xPositionAbs = []
                            self.yPositionAbs = []
                            self.xPulse = []
                            self.yPulse = []
                            self.sampleId = []
                            self.area = []
                            self.position_shift = [0, 0]
                            os.chdir(
                                'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')

                            # with open(self.filename1, "a") as filewrite:
                            #     filewrite.write(str(self.cycleIndex)+"__")
                            #     pass

                            with open('Points need to be acquired.txt', 'r') as f:
                                pulse = f.readline()
                                while pulse:
                                    # print('data2:{}, type2:{}'.format(str2,type(str2)))
                                    x_tmp, y_tmp = [float(i) for i in pulse.split()]
                                    x_tmp = (x_tmp)
                                    y_tmp = (y_tmp)
                                    self.xPosition.append(x_tmp)
                                    self.yPosition.append(y_tmp)
                                    pulse = f.readline()
                                    pass
                                pass
                            with open('Points need to be acquired(abs).txt', 'r') as f:
                                pulse = f.readline()
                                while pulse:
                                    # print('data2:{}, type2:{}'.format(str2,type(str2)))
                                    x_tmp, y_tmp = [float(i) for i in pulse.split()]
                                    x_tmp = int(x_tmp)
                                    y_tmp = int(y_tmp)
                                    self.xPositionAbs.append(x_tmp)
                                    self.yPositionAbs.append(y_tmp)
                                    pulse = f.readline()
                                    pass
                                pass
                            with open('MotorPulse.txt', 'r') as f:
                                pulse = f.readline()
                                while pulse:
                                    # print('data2:{}, type2:{}'.format(str2,type(str2)))
                                    x_tmp, y_tmp = [float(i) for i in pulse.split()]
                                    x_tmp = int(x_tmp)
                                    y_tmp = int(y_tmp)
                                    # print(x_tmp)
                                    # print(y_tmp)
                                    self.xPulse.append(x_tmp)
                                    self.yPulse.append(y_tmp)
                                    pulse = f.readline()
                                    pass
                                pass

                            with open('idd.txt', 'r') as f:
                                idd = f.readline()
                                while idd:
                                    self.sampleId.append(idd)
                                    idd = f.readline()
                                    pass
                                pass

                            with open('area.txt', 'r') as f:
                                area = f.readline()
                                while area:
                                    self.area.append(area)
                                    area = f.readline()
                                    pass
                                pass

                            if len(self.xPosition):

                                self.cycleIndex += 1
                                os.chdir(
                                    'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
                                filename = str(self.cycleIndex) + 'OriginalImage' + '.jpg'
                                image = Image.fromarray(self.img1, mode=None)
                                image.save(filename)

                                filename = str(self.cycleIndex) + 'OriginalImage Marked' + '.jpg'
                                image = Image.fromarray(self.img3, mode=None)
                                image.save(filename)

                                self.xshift = 0
                                self.yshift = 0

                                # Turn on LED
                                self.serialMove.changevoltage(self.ser, 1)
                                time.sleep(0.1)

                                # Block Laser
                                self.serialMove.ServoMovement(self.ser, -1)
                                time.sleep(0.6)

                                self.serialMove.movement(self.ser, 'X Axis', self.yPulse[0])
                                sleepPerid = self.timeInterval(abs(self.yPulse[0]))
                                time.sleep(sleepPerid)
                                # time.sleep(2.5)

                                self.serialMove.movement(self.ser, 'Y Axis', self.xPulse[0])
                                sleepPerid = self.timeInterval(abs(self.xPulse[0]))
                                time.sleep(sleepPerid)
                                # time.sleep(2.5)
                                FinishedAutofocusFlag = False
                                pass

                            elif len(self.xPosition) == 0:
                                print('Autofocusing!!!2')
                                # self.movement(600, 'X Axis')
                                # self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                # self.xWay += self.xStep
                                # sleepPerid = self.timeInterval(abs(self.xStep))
                                # time.sleep(sleepPerid)
                                # time.sleep(3)

                                # self.serialMove.movement(self.ser, 'Y Axis', -600)
                                # self.xWay += -600
                                # time.sleep(3)
                                # self.AutoFoucs()
                                # self._signal.emit(1)
                                # focusingFlag = True

                                lfx, lfy = 30, 30
                                rgx, rgy = int(self.w - 30), int(self.yLaserPosition - 15)
                                imgTemp = GetMVFrame(self.hcamera)
                                _, thresh = cv2.threshold(imgTemp[lfy:rgy, lfx:rgx], 60, 255, cv2.THRESH_BINARY_INV)
                                kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))  # 定义矩形结构元素
                                opening = cv2.morphologyEx(thresh, cv2.MORPH_GRADIENT, kernel)  # 梯度
                                print('np.sum(opening) is :{}'.format(np.sum(opening)))
                                if self.xStep >= 0:
                                    if np.sum(opening) >= 9000:
                                        self.serialMove.movement(self.ser, 'X Axis', 350)
                                        # self.xWay += 50
                                        time.sleep(0.3)
                                        self._signal.emit(1)
                                        focusingFlag = True
                                        FinishedAutofocusFlag = False
                                        pass
                                    else:
                                        time.sleep(0.35)
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(abs(self.xStep))
                                        time.sleep(sleepPerid)
                                        pass
                                    pass

                                elif self.xStep < 0:
                                    if np.sum(opening) >= 20000:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        self._signal.emit(1)
                                        focusingFlag = True
                                        self.FishedRamanacquiredFlag = False
                                        pass
                                    else:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        # time.sleep(3)
                                        pass
                                    pass
                                pass
                            pass

                        else:
                            if self.FishedRamanacquiredFlag:
                                # finished Raman spectra acquisition in one frame
                                print('Finished Raman acquisition')

                                # self.serialMove.movement(self.ser, 'Y Axis', -600)
                                # self.yWay += -600
                                # time.sleep(3)

                                # start autofocus
                                lfx, lfy = 30, 30
                                rgx, rgy = int(self.w - 30), int(self.yLaserPosition - 15)
                                print(rgx, rgy)
                                imgTemp = GetMVFrame(self.hcamera)
                                _, thresh = cv2.threshold(imgTemp[lfy:rgy, lfx:rgx], 100, 255, cv2.THRESH_BINARY_INV)
                                kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))  # 定义矩形结构元素
                                opening = cv2.morphologyEx(thresh, cv2.MORPH_GRADIENT, kernel)  # 梯度
                                print('np.sum(opening) is :{}'.format(np.sum(opening)))
                                if self.xStep >= 0:
                                    if np.sum(opening) >= 9000:
                                        self.serialMove.movement(self.ser, 'X Axis', 350)
                                        time.sleep(0.3)
                                        self.xWay += 350
                                        self._signal.emit(1)
                                        focusingFlag = True
                                        self.FishedRamanacquiredFlag = False
                                        pass
                                    else:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)

                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        # time.sleep(3)
                                        pass
                                elif self.xStep < 0:
                                    if np.sum(opening) >= 20000:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        self._signal.emit(1)
                                        focusingFlag = True
                                        self.FishedRamanacquiredFlag = False
                                        pass
                                    else:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)

                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        # time.sleep(3)
                                        pass
                                    pass
                                pass
                            else:
                                # acquire Raman spectra
                                self.img2 = GetMVFrame(self.hcamera)
                                # 显示图片
                                # x = self.img2.shape[1]
                                # y = self.img2.shape[0]
                                # Qframe = QImage(self.img2, x, y, x, QImage.Format_Grayscale8)
                                # pixmap = QPixmap(Qframe)
                                # self.Viewer2.setPixmap(pixmap)
                                # self.Viewer2.setScaledContents(True)  # 图片自适应

                                if self.AcqNums <= len(self.xPosition) - 1:
                                    self.position_shift = self.Imgprocessor.imagecompare(self.img1, self.img2,
                                                                            [int(self.xPositionAbs[self.AcqNums]),
                                                                             int(self.yPositionAbs[self.AcqNums])],
                                                                            [int(self.xLaserPosition),
                                                                             int(self.yLaserPosition)])

                                    xTemp = self.xPositionAbs[self.AcqNums] + self.position_shift[0]
                                    yTemp = self.yPositionAbs[self.AcqNums] + self.position_shift[1]

                                    lfxposInsrc, lfyposInsrc = int(self.xPositionAbs[self.AcqNums]) - 7, int(self.yPositionAbs[self.AcqNums]) - 10
                                    rixposInsrc, riyposInsrc = int(self.xPositionAbs[self.AcqNums]) + 7, int(self.yPositionAbs[self.AcqNums]) + 10
                                    # print('lfxposInsrc is:{}, lfyposInsrc is:{}'.format(lfxposInsrc, lfyposInsrc))
                                    # lfxposIntar, lfyposIntar = int(self.xLaserPosition) - 7, int(self.yLaserPosition) - 10
                                    # rixposIntar, riyposIntar = int(self.xLaserPosition) + 7, int(self.yLaserPosition) + 10
                                    lfxposIntar, lfyposIntar = int(xTemp) - 7, int(yTemp) - 10
                                    rixposIntar, riyposIntar = int(xTemp) + 7, int(yTemp) + 10
                                    # print('lfxposIntar is:{}, lfyposIntar is:{}'.format(lfxposIntar, lfyposIntar))

                                    # cv2.namedWindow('Gray value in source image', cv2.WINDOW_NORMAL)
                                    # cv2.resizeWindow('Gray value in source image', 480, 360)
                                    # cv2.imshow('Gray value in source image',
                                    #            self.img1[lfyposInsrc:riyposInsrc, lfxposInsrc:rixposInsrc])
                                    #
                                    # cv2.namedWindow('Gray value in target image', cv2.WINDOW_NORMAL)
                                    # cv2.resizeWindow('Gray value in target image', 480, 360)
                                    # cv2.imshow('Gray value in target image',
                                    #            self.img2[lfyposIntar:riyposIntar, lfxposIntar:rixposIntar])
                                    # cv2.waitKey()
                                    # cv2.destroyAllWindows()

                                    # *0.87
                                    # self.sourceGrayValue = np.sum(self.img1[lfyposInsrc:riyposInsrc, lfxposInsrc:rixposInsrc])
                                    # self.targetGaryValue = np.sum(self.img2[lfyposIntar:riyposIntar, lfxposIntar:rixposIntar])

                                    # *0.8
                                    self.sourceGrayValue = np.max(
                                        self.img1[lfyposInsrc:riyposInsrc, lfxposInsrc:rixposInsrc])
                                    self.targetGaryValue = np.max(
                                        self.img2[lfyposIntar:riyposIntar, lfxposIntar:rixposIntar])
                                    # print('self.sourceGrayValue is :{}'.format(self.sourceGrayValue))
                                    # print('self.targetGaryValue is :{}'.format(self.targetGaryValue))
                                    # juage whether it is in focus
                                    if self.targetGaryValue <= self.sourceGrayValue * 0.8:
                                        # self.AutoFoucs()
                                        lfx, lfy = 30, 30
                                        rgx, rgy = int(self.w - 30), int(self.yLaserPosition - 15)
                                        imgTemp = GetMVFrame(self.hcamera)
                                        _, thresh = cv2.threshold(imgTemp[lfy:rgy, lfx:rgx], 70, 255,
                                                                  cv2.THRESH_BINARY_INV)
                                        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))  # 定义矩形结构元素
                                        opening = cv2.morphologyEx(thresh, cv2.MORPH_GRADIENT, kernel)  # 梯度
                                        # print('np.sum(opening) is :{}'.format(np.sum(opening)))
                                        if self.xStep >= 0:
                                            if np.sum(opening) >= 9000:
                                                self.serialMove.movement(self.ser, 'X Axis', 850)
                                                self.xWay += 850
                                                time.sleep(0.3)
                                                self._signal.emit(1)
                                                focusingFlag = True
                                                pass
                                            else:
                                                self.serialMove.movement(self.ser, 'X Axis', 1000)
                                                self.xWay += 1000
                                                time.sleep(3)
                                                self._signal.emit(1)
                                                focusingFlag = True
                                                pass
                                            pass
                                        elif self.xStep < 0:
                                            if np.sum(opening) >= 20000:
                                                self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                                self.xWay += self.xStep
                                                sleepPerid = self.timeInterval(self.xStep)
                                                time.sleep(sleepPerid)
                                                self._signal.emit(1)
                                                focusingFlag = True
                                                self.FishedRamanacquiredFlag = False
                                                pass
                                            else:
                                                self.serialMove.movement(self.ser, 'X Axis', self.xStep)

                                                self.xWay += self.xStep
                                                sleepPerid = self.timeInterval(self.xStep)
                                                time.sleep(sleepPerid)
                                                self._signal.emit(1)
                                                focusingFlag = True
                                                # time.sleep(3)
                                                pass
                                            pass
                                        pass
                                    else:

                                        # print('xTemp is:{}, yTemp is:{}'.format(xTemp, yTemp))
                                        if (xTemp - self.xLaserPosition) ** 2 + (
                                                yTemp - self.yLaserPosition) ** 2 <= 3:
                                            # Turn off LED
                                            self.serialMove.changevoltage(self.ser, -1)
                                            time.sleep(0.1)

                                            # send in Laser
                                            self.serialMove.ServoMovement(self.ser, 1)
                                            time.sleep(0.6)

                                            # print('Start to acquire Raman spectra!!!')
                                            # Acquire Raman spectra
                                            img = self.camera.capture()
                                            time.sleep(self.sleepPeriod*1.2)
                                            rows = img.shape[0]
                                            sp = np.sum(img, axis=0) / rows

                                            os.chdir(
                                                'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')

                                            with open(self.filename1, "a") as filewrite:
                                                filewrite.write(str(self.cycleIndex) + ",  " + str(
                                                    self.sampleId[self.AcqNums]) + " ")
                                                pass

                                            with open(self.filename2, "a") as filewrite:
                                                filewrite.write(str(self.cycleIndex) + ",  " + str(
                                                    self.area[self.AcqNums]) + " ")
                                                pass
                                            time.sleep(0.3)

                                            # self.curve.setData(sp)
                                            # curr_time = datetime.datetime.now()
                                            # time_str = datetime.datetime.strftime(curr_time, '%Y_%m_%d_%H_%M_%S')
                                            #
                                            # filename = str(time_str) + '.txt'
                                            # os.chdir(
                                            #     'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\RamanSpectra')
                                            # np.savetxt(filename, sp)
                                            self._RamanSignal.emit(sp)
                                            self.currentframe += 1
                                            # self.lineEdit_CurrentFrame.setText(str(self.currentframe))



                                            # Turn on LED
                                            self.serialMove.changevoltage(self.ser, 1)
                                            time.sleep(0.1)

                                            # Block Laser
                                            # time.sleep(0.3)
                                            self.serialMove.ServoMovement(self.ser, -1)
                                            time.sleep(0.6)


                                            if self.AcqNums == len(self.xPosition) - 1:
                                                self.AcqNums += 1
                                                self.FishedRamanacquiredFlag = True
                                                # time.sleep(0.5)
                                                pass
                                            else:
                                                self.AcqNums += 1
                                                self.serialMove.movement(self.ser, 'X Axis', self.yPulse[self.AcqNums])
                                                sleepPerid = self.timeInterval(self.yPulse[self.AcqNums])
                                                time.sleep(sleepPerid)
                                                # time.sleep(2.5)
                                                self.serialMove.movement(self.ser, 'Y Axis', self.xPulse[self.AcqNums])
                                                sleepPerid = self.timeInterval(self.xPulse[self.AcqNums])
                                                time.sleep(sleepPerid)
                                                # time.sleep(2.5)
                                                pass
                                            pass

                                        else:
                                            # print('Keep moving!!!')
                                            self.xshift = int(
                                                (self.xLaserPosition - xTemp) * self.fittingSlopeY + self.fittingInterceptY)
                                            self.yshift = int(
                                                (self.yLaserPosition - yTemp) * self.fittingSlope + self.fittingIntercept)
                                            self.serialMove.movement(self.ser, 'X Axis', self.yshift)
                                            sleepPerid = self.timeInterval(self.yshift)
                                            time.sleep(sleepPerid)
                                            # time.sleep(2)
                                            self.serialMove.movement(self.ser, 'Y Axis', self.xshift)
                                            sleepPerid = self.timeInterval(self.xshift)
                                            time.sleep(sleepPerid)
                                            # time.sleep(2)
                                            pass
                                        pass
                                    # juage whether it is in focus

                                    pass

                                else:
                                    pass
                                pass
                            pass
                        # judge whether finished data acquisition in one frame
                        pass

                    # judge whether it is in autofocus state

                    # To aviod damage the objective
                    if abs(self.xWay) >= 15500 and not focusingFlag:
                        # self.serialMove.movement(self.ser, 'X Axis', round(-self.xWay/4))
                        # self.xWay = 0
                        # time.sleep(10)
                        self.xWay = 0
                        self.xWayNum += 1
                        if self.xWayNum == 12 and not focusingFlag:
                            self.xWayNum = 0
                            self.serialMove.movement(self.ser, 'Y Axis', -4000)
                            self.yWay += -4000
                            time.sleep(6)
                            # self.serialMove.movement(self.ser, 'Y Axis', -4000)
                            # self.yWay += -4000
                            # time.sleep(5)
                            if self.xStep == 800:
                                self.xStep = -1500
                                pass
                            elif self.xStep == -1500:
                                self.xStep = 800
                                pass
                            self._signal.emit(1)
                            focusingFlag = True
                            pass
                        print('xWayNum is:{}'.format(self.xWayNum))
                        pass

                    if abs(self.yWay) >= 15500 and not focusingFlag:
                        # self.serialMove.movement(self.ser, 'Y Axis', round(-self.yWay/4))
                        # self.yWay = 0
                        # time.sleep(10)
                        self.yWay = 0
                        self.yWayNum += 1
                        if self.yWayNum == 12:
                            self.yWayNum = 0
                            self.serialMove.movement(self.ser, 'X Axis', 1500)
                            self.xWay += 1500
                            time.sleep(4)
                            if self.yStep == -800:
                                self.yStep = 1500
                                pass
                            elif self.yStep == 1500:
                                self.yStep = -800
                                pass
                            self._signal.emit(1)
                            focusingFlag = True
                            pass
                        print('yWayNum is:{}'.format(self.yWayNum))
                        # self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                        # time.sleep(3)
                        # self.xWay += self.xStep
                        # self.yStep = -self.yStep
                        # self._signal.emit(1)
                        # focusingFlag = True
                        pass
                    # To aviod damage the objective
                    # print('self.xWay is: {}'.format(self.xWay))
                    pass

                else:
                    # print('Stop acquisition!!!!')
                    pass
                # if we clicked "Stop acquisition" button we will stop current acquisition!!!

            else:
                self.AutoAcqWorking = False
                pass
            # img = self.fun.capture()
            # self._signal.emit(img)
            time.sleep(0.5)
            pass
        pass

    pass

# for beads time series
class AutoAcquisitionThread2(QThread):
    AutoAcqWorking = True
    _signal = pyqtSignal(int)
    _RamanSignal = pyqtSignal(np.ndarray)
    sleepTimeInterval = 0.5
    def __init__(self, argument_):
        super().__init__()
        # print('Thread Init')
        # self.fun = argument_
        self.serialMove = SerialPort()
        self.Imgprocessor = ImgProcess()
        self.FishedRamanacquiredFlag = False
        self.currentframe = 0
        self.cycleIndex = 1
        self.AcqNums = 0

        self.TotalNum = argument_[0]
        self.hcamera = argument_[1]
        self.camera = argument_[2]
        self.Viewer = argument_[3]
        self.Viewer2 = argument_[4]
        self.ser = argument_[5]
        self.curve = argument_[6]
        self.lineEdit_CurrentFrame = argument_[7]
        self.xPosition = argument_[8]
        self.img1 = argument_[9]
        self.xPositionAbs = argument_[10]
        self.yPositionAbs = argument_[11]
        self.xLaserPosition = argument_[12]
        self.yLaserPosition = argument_[13]
        self.fittingSlope = argument_[14]
        self.fittingIntercept = argument_[15]
        self.fittingSlopeY = argument_[16]
        self.fittingInterceptY = argument_[17]
        self.xPulse = argument_[18]
        self.yPulse = argument_[19]
        self.w = argument_[20]
        self.h = argument_[21]
        self.sleepPeriod = argument_[22]
        self.timeSeries = argument_[23]

        self.xWay, self.yWay = 0, 0
        self.xWayNum, self.yWayNum = 0, 0
        global FinishedAutofocusFlag
        FinishedAutofocusFlag = False

        self.xStep = 800
        self.yStep = -800
        # # Block Laser
        # self.serialMove.ServoMovement(self.ser, -1)
        # time.sleep(0.5)
        # # Turn on LED
        # self.serialMove.changevoltage(self.ser, 1)
        # time.sleep(0.1)
        #
        # self.serialMove.movement(self.ser, 'X Axis', self.yPulse[0])
        # time.sleep(2)
        # self.serialMove.movement(self.ser, 'Y Axis', self.xPulse[0])
        # time.sleep(2)
        pass

    def __del__(self):
        self.working = False
        # self.wait()
        pass

    def timeInterval(self, pulse):
        if pulse <= 50:
            self.sleepTimeInterval = 0.3
            pass
        elif pulse <= 100:
            self.sleepTimeInterval = 0.55
            pass
        elif pulse > 100 and pulse >= 600:
            self.sleepTimeInterval = 0.55 + int(round(pulse/100)) * 0.3
            pass
        elif pulse <= 1500:
            self.sleepTimeInterval = 3
            pass
        elif pulse <= 2000:
            self.sleepTimeInterval = 3.5
            pass
        else:
            self.sleepTimeInterval = 5
            pass
        return self.sleepTimeInterval

    def run(self):
        # We can click "Quit Acquisition" Button which would chaneg the gobal varible "autoAcqFlag" to end current porcess
        while self.AutoAcqWorking and autoAcqFlag:
            frame = GetMVFrame(self.hcamera)
            x = frame.shape[1]
            y = frame.shape[0]
            Qframe = QImage(frame, x, y, x, QImage.Format_Grayscale8)
            pixmap = QPixmap(Qframe)
            self.Viewer2.setPixmap(pixmap)
            self.Viewer2.setScaledContents(True)  # 图片自适应

            if self.currentframe < self.TotalNum:
                # if we clicked "Stop acquisition" button we will stop current acquisition!!!
                global stopAutoAcqFlag
                if not stopAutoAcqFlag:
                    # judge whether it is in autofocus state
                    global focusingFlag
                    if focusingFlag:
                        print('Autofocusing!!!')
                        pass

                    else:
                        # judge whether finished data acquisition in one frame
                        global FinishedAutofocusFlag
                        if FinishedAutofocusFlag:
                            # 图相处理，添加更新位置坐标，以及脉冲的数量的txt文件
                            self.img1 = GetMVFrame(self.hcamera)
                            self.img3 = self.img1.copy()
                            self.Imgprocessor.imgSegment(self.img3, 200, cv2.MORPH_ELLIPSE, (3, 3), 0.2, self.w, self.h)
                            time.sleep(0.1)
                            # self.imageTracingFlag = True
                            self.AcqNums = 0
                            self.xPosition = []
                            self.yPosition = []
                            self.xPositionAbs = []
                            self.yPositionAbs = []
                            self.xPulse = []
                            self.yPulse = []
                            self.sampleId = []
                            self.position_shift = [0, 0]
                            os.chdir(
                                'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')

                            with open('Points need to be acquired.txt', 'r') as f:
                                pulse = f.readline()
                                while pulse:
                                    # print('data2:{}, type2:{}'.format(str2,type(str2)))
                                    x_tmp, y_tmp = [float(i) for i in pulse.split()]
                                    x_tmp = (x_tmp)
                                    y_tmp = (y_tmp)
                                    self.xPosition.append(x_tmp)
                                    self.yPosition.append(y_tmp)
                                    pulse = f.readline()
                                    pass
                                pass

                            with open('Points need to be acquired(abs).txt', 'r') as f:
                                pulse = f.readline()
                                while pulse:
                                    # print('data2:{}, type2:{}'.format(str2,type(str2)))
                                    x_tmp, y_tmp = [float(i) for i in pulse.split()]
                                    x_tmp = int(x_tmp)
                                    y_tmp = int(y_tmp)
                                    self.xPositionAbs.append(x_tmp)
                                    self.yPositionAbs.append(y_tmp)
                                    pulse = f.readline()
                                    pass
                                pass

                            with open('MotorPulse.txt', 'r') as f:
                                pulse = f.readline()
                                while pulse:
                                    # print('data2:{}, type2:{}'.format(str2,type(str2)))
                                    x_tmp, y_tmp = [float(i) for i in pulse.split()]
                                    x_tmp = int(x_tmp)
                                    y_tmp = int(y_tmp)
                                    # print(x_tmp)
                                    # print(y_tmp)
                                    self.xPulse.append(x_tmp)
                                    self.yPulse.append(y_tmp)
                                    pulse = f.readline()
                                    pass
                                pass


                            if len(self.xPosition):

                                self.cycleIndex += 1
                                os.chdir(
                                    'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
                                filename = str(self.cycleIndex) + 'OriginalImage' + '.jpg'
                                image = Image.fromarray(self.img1, mode=None)
                                image.save(filename)

                                filename = str(self.cycleIndex) + 'OriginalImage Marked' + '.jpg'
                                image = Image.fromarray(self.img3, mode=None)
                                image.save(filename)

                                self.xshift = 0
                                self.yshift = 0

                                # Turn on LED
                                self.serialMove.changevoltage(self.ser, 1)
                                time.sleep(0.1)
                                # Block Laser
                                self.serialMove.ServoMovement(self.ser, -1)
                                time.sleep(0.6)


                                self.serialMove.movement(self.ser, 'X Axis', self.yPulse[0])
                                sleepPerid = self.timeInterval(abs(self.yPulse[0]))
                                time.sleep(sleepPerid)
                                # time.sleep(2.5)

                                self.serialMove.movement(self.ser, 'Y Axis', self.xPulse[0])
                                sleepPerid = self.timeInterval(abs(self.xPulse[0]))
                                time.sleep(sleepPerid)
                                # time.sleep(2.5)
                                FinishedAutofocusFlag = False
                                pass

                            elif len(self.xPosition) == 0:
                                print('Autofocusing!!!2')
                                # self.movement(600, 'X Axis')
                                # self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                # self.xWay += self.xStep
                                # sleepPerid = self.timeInterval(abs(self.xStep))
                                # time.sleep(sleepPerid)
                                # time.sleep(3)

                                # self.serialMove.movement(self.ser, 'Y Axis', -600)
                                # self.xWay += -600
                                # time.sleep(3)
                                # self.AutoFoucs()
                                # self._signal.emit(1)
                                # focusingFlag = True

                                lfx, lfy = 30, 30
                                rgx, rgy = int(self.w - 30), int(self.yLaserPosition - 15)
                                imgTemp = GetMVFrame(self.hcamera)
                                _, thresh = cv2.threshold(imgTemp[lfy:rgy, lfx:rgx], 60, 255, cv2.THRESH_BINARY_INV)
                                kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))  # 定义矩形结构元素
                                opening = cv2.morphologyEx(thresh, cv2.MORPH_GRADIENT, kernel)  # 梯度
                                print('np.sum(opening) is :{}'.format(np.sum(opening)))
                                if self.xStep >= 0:
                                    if np.sum(opening) >= 9000:
                                        self.serialMove.movement(self.ser, 'X Axis', 350)
                                        # self.xWay += 50
                                        time.sleep(0.3)
                                        self._signal.emit(1)
                                        focusingFlag = True
                                        FinishedAutofocusFlag = False
                                        pass
                                    else:
                                        time.sleep(0.35)
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(abs(self.xStep))
                                        time.sleep(sleepPerid)
                                        pass
                                    pass

                                elif self.xStep < 0:
                                    if np.sum(opening) >= 20000:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        self._signal.emit(1)
                                        focusingFlag = True
                                        self.FishedRamanacquiredFlag = False
                                        pass
                                    else:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        # time.sleep(3)
                                        pass
                                    pass
                                pass
                            pass

                        else:
                            if self.FishedRamanacquiredFlag:
                                # finished Raman spectra acquisition in one frame
                                print('Finished Raman acquisition')

                                # self.serialMove.movement(self.ser, 'Y Axis', -600)
                                # self.yWay += -600
                                # time.sleep(3)

                                # start autofocus
                                lfx, lfy = 30, 30
                                rgx, rgy = int(self.w - 30), int(self.yLaserPosition - 15)
                                print(rgx, rgy)
                                imgTemp = GetMVFrame(self.hcamera)
                                _, thresh = cv2.threshold(imgTemp[lfy:rgy, lfx:rgx], 70, 255, cv2.THRESH_BINARY_INV)
                                kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))  # 定义矩形结构元素
                                opening = cv2.morphologyEx(thresh, cv2.MORPH_GRADIENT, kernel)  # 梯度
                                # print('np.sum(opening) is :{}'.format(np.sum(opening)))
                                if self.xStep >= 0:
                                    if np.sum(opening) >= 9000:
                                        self.serialMove.movement(self.ser, 'X Axis', 350)
                                        time.sleep(0.3)
                                        self.xWay += 350
                                        self._signal.emit(1)
                                        focusingFlag = True
                                        self.FishedRamanacquiredFlag = False
                                        pass
                                    else:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)

                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        # time.sleep(3)
                                        pass
                                elif self.xStep < 0:
                                    if np.sum(opening) >= 20000:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        self._signal.emit(1)
                                        focusingFlag = True
                                        self.FishedRamanacquiredFlag = False
                                        pass
                                    else:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)

                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        # time.sleep(3)
                                        pass
                                    pass
                                pass
                            else:
                                # acquire Raman spectra
                                self.img2 = GetMVFrame(self.hcamera)
                                if self.AcqNums <= len(self.xPosition) - 1:
                                    self.position_shift = self.Imgprocessor.imagecompare(self.img1, self.img2,
                                                                            [int(self.xPositionAbs[self.AcqNums]),
                                                                             int(self.yPositionAbs[self.AcqNums])],
                                                                            [int(self.xLaserPosition),
                                                                             int(self.yLaserPosition)])

                                    xTemp = self.xPositionAbs[self.AcqNums] + self.position_shift[0]
                                    yTemp = self.yPositionAbs[self.AcqNums] + self.position_shift[1]

                                    lfxposInsrc, lfyposInsrc = int(self.xPositionAbs[self.AcqNums]) - 7, int(self.yPositionAbs[self.AcqNums]) - 10
                                    rixposInsrc, riyposInsrc = int(self.xPositionAbs[self.AcqNums]) + 7, int(self.yPositionAbs[self.AcqNums]) + 10

                                    lfxposIntar, lfyposIntar = int(xTemp) - 7, int(yTemp) - 10
                                    rixposIntar, riyposIntar = int(xTemp) + 7, int(yTemp) + 10

                                    # *0.87
                                    # self.sourceGrayValue = np.sum(self.img1[lfyposInsrc:riyposInsrc, lfxposInsrc:rixposInsrc])
                                    # self.targetGaryValue = np.sum(self.img2[lfyposIntar:riyposIntar, lfxposIntar:rixposIntar])

                                    # *0.8
                                    self.sourceGrayValue = np.max(
                                        self.img1[lfyposInsrc:riyposInsrc, lfxposInsrc:rixposInsrc])
                                    self.targetGaryValue = np.max(
                                        self.img2[lfyposIntar:riyposIntar, lfxposIntar:rixposIntar])
                                    # juage whether it is in focus
                                    if self.targetGaryValue <= self.sourceGrayValue * 0.8:
                                        # self.AutoFoucs()
                                        lfx, lfy = 30, 30
                                        rgx, rgy = int(self.w - 30), int(self.yLaserPosition - 15)
                                        imgTemp = GetMVFrame(self.hcamera)
                                        _, thresh = cv2.threshold(imgTemp[lfy:rgy, lfx:rgx], 70, 255,
                                                                  cv2.THRESH_BINARY_INV)
                                        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))  # 定义矩形结构元素
                                        opening = cv2.morphologyEx(thresh, cv2.MORPH_GRADIENT, kernel)  # 梯度
                                        # print('np.sum(opening) is :{}'.format(np.sum(opening)))
                                        if self.xStep >= 0:
                                            if np.sum(opening) >= 9000:
                                                self.serialMove.movement(self.ser, 'X Axis', 350)
                                                self.xWay += 350
                                                time.sleep(0.3)
                                                self._signal.emit(1)
                                                focusingFlag = True
                                                pass
                                            else:
                                                self.serialMove.movement(self.ser, 'X Axis', 1000)
                                                self.xWay += 1000
                                                time.sleep(3)
                                                pass
                                            pass
                                        elif self.xStep < 0:
                                            if np.sum(opening) >= 20000:
                                                self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                                self.xWay += self.xStep
                                                sleepPerid = self.timeInterval(self.xStep)
                                                time.sleep(sleepPerid)
                                                self._signal.emit(1)
                                                focusingFlag = True
                                                self.FishedRamanacquiredFlag = False
                                                pass
                                            else:
                                                self.serialMove.movement(self.ser, 'X Axis', self.xStep)

                                                self.xWay += self.xStep
                                                sleepPerid = self.timeInterval(self.xStep)
                                                time.sleep(sleepPerid)
                                                # time.sleep(3)
                                                pass
                                            pass
                                        pass
                                    else:
                                        if (xTemp - self.xLaserPosition) ** 2 + (
                                                yTemp - self.yLaserPosition) ** 2 <= 4:

                                            # Turn off LED
                                            self.serialMove.changevoltage(self.ser, -1)
                                            time.sleep(0.1)

                                            # send in Laser
                                            self.serialMove.ServoMovement(self.ser, 1)
                                            time.sleep(0.6)

                                            for i in self.timeSeries:
                                                # print('Start to acquire Raman spectra!!!')
                                                # Acquire Raman spectra
                                                img = self.camera.capture()
                                                time.sleep(self.sleepPeriod*1.2)
                                                rows = img.shape[0]
                                                sp = np.sum(img, axis=0) / rows
                                                # self.curve.setData(sp)

                                                # curr_time = datetime.datetime.now()
                                                # time_str = datetime.datetime.strftime(curr_time, '%Y_%m_%d_%H_%M_%S')

                                                filename = str(self.currentframe) + ',' + i + '.txt'
                                                os.chdir(
                                                    'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\RamanSpectra')
                                                np.savetxt(filename, sp)

                                                self._RamanSignal.emit(sp)
                                                time.sleep(0.1)
                                                self.camera.set_control_value(asi.ASI_EXPOSURE, int(i))
                                                time.sleep(0.1)
                                                pass

                                            self.camera.set_control_value(asi.ASI_EXPOSURE, int(self.timeSeries[0]))
                                            self.currentframe += 1
                                            # self.lineEdit_CurrentFrame.setText(str(self.currentframe))

                                            # Turn on LED
                                            self.serialMove.changevoltage(self.ser, 1)
                                            time.sleep(0.1)

                                            # Block Laser
                                            # time.sleep(0.3)
                                            self.serialMove.ServoMovement(self.ser, -1)
                                            time.sleep(0.6)


                                            if self.AcqNums == len(self.xPosition) - 1:
                                                self.AcqNums += 1
                                                self.FishedRamanacquiredFlag = True
                                                # time.sleep(0.5)
                                                pass
                                            else:
                                                self.AcqNums += 1
                                                self.serialMove.movement(self.ser, 'X Axis', self.yPulse[self.AcqNums])
                                                sleepPerid = self.timeInterval(self.yPulse[self.AcqNums])
                                                time.sleep(sleepPerid)
                                                # time.sleep(2.5)
                                                self.serialMove.movement(self.ser, 'Y Axis', self.xPulse[self.AcqNums])
                                                sleepPerid = self.timeInterval(self.xPulse[self.AcqNums])
                                                time.sleep(sleepPerid)
                                                # time.sleep(2.5)
                                                pass

                                            pass

                                        else:
                                            # print('Keep moving!!!')
                                            self.xshift = int(
                                                (self.xLaserPosition - xTemp) * self.fittingSlopeY + self.fittingInterceptY)
                                            self.yshift = int(
                                                (self.yLaserPosition - yTemp) * self.fittingSlope + self.fittingIntercept)
                                            self.serialMove.movement(self.ser, 'X Axis', self.yshift)
                                            sleepPerid = self.timeInterval(self.yshift)
                                            time.sleep(sleepPerid)
                                            # time.sleep(2)
                                            self.serialMove.movement(self.ser, 'Y Axis', self.xshift)
                                            sleepPerid = self.timeInterval(self.xshift)
                                            time.sleep(sleepPerid)
                                            # time.sleep(2)
                                            pass
                                        pass
                                    # juage whether it is in focus

                                    pass

                                else:
                                    pass
                                pass
                            pass
                        # judge whether finished data acquisition in one frame
                        pass

                    # judge whether it is in autofocus state

                    # To aviod damage the objective
                    if abs(self.xWay) >= 9500 and not focusingFlag:
                        # self.serialMove.movement(self.ser, 'X Axis', round(-self.xWay/4))
                        # self.xWay = 0
                        # time.sleep(10)
                        self.xWay = 0
                        self.xWayNum += 1
                        if self.xWayNum == 12 and not focusingFlag:
                            self.xWayNum = 0
                            self.serialMove.movement(self.ser, 'Y Axis', -4000)
                            self.yWay += -4000
                            time.sleep(6)
                            # self.serialMove.movement(self.ser, 'Y Axis', -4000)
                            # self.yWay += -4000
                            # time.sleep(5)
                            if self.xStep == 800:
                                self.xStep = -1500
                                pass
                            elif self.xStep == -1500:
                                self.xStep = 800
                                pass
                            self._signal.emit(1)
                            focusingFlag = True
                            pass
                        print('xWayNum is:{}'.format(self.xWayNum))
                        pass

                    if abs(self.yWay) >= 9500 and not focusingFlag:
                        # self.serialMove.movement(self.ser, 'Y Axis', round(-self.yWay/4))
                        # self.yWay = 0
                        # time.sleep(10)
                        self.yWay = 0
                        self.yWayNum += 1
                        if self.yWayNum == 12:
                            self.yWayNum = 0
                            self.serialMove.movement(self.ser, 'X Axis', 1500)
                            self.xWay += 1500
                            time.sleep(4)
                            if self.yStep == -800:
                                self.yStep = 1500
                                pass
                            elif self.yStep == 1500:
                                self.yStep = -800
                                pass
                            self._signal.emit(1)
                            focusingFlag = True
                            pass
                        print('yWayNum is:{}'.format(self.yWayNum))
                        # self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                        # time.sleep(3)
                        # self.xWay += self.xStep
                        # self.yStep = -self.yStep
                        # self._signal.emit(1)
                        # focusingFlag = True
                        pass
                    # To aviod damage the objective
                    # print('self.xWay is: {}'.format(self.xWay))
                    pass

                else:
                    # print('Stop acquisition!!!!')
                    pass
                # if we clicked "Stop acquisition" button we will stop current acquisition!!!

            else:
                self.AutoAcqWorking = False
                pass
            # img = self.fun.capture()
            # self._signal.emit(img)
            time.sleep(0.5)
            pass
        pass

    pass

# for cells
class AutoAcquisitionThread3(QThread):
    AutoAcqWorking = True
    _signal = pyqtSignal(int)
    _RamanSignal = pyqtSignal(np.ndarray)
    sleepTimeInterval = 0.5
    def __init__(self, argument_):
        super().__init__()
        # print('Thread Init')
        # self.fun = argument_
        self.serialMove = SerialPort()
        self.Imgprocessor = ImgProcess()
        self.FishedRamanacquiredFlag = False
        self.currentframe = 0
        self.cycleIndex = 1
        self.AcqNums = 0

        self.TotalNum = argument_[0]
        self.hcamera = argument_[1]
        self.camera = argument_[2]
        self.Viewer = argument_[3]
        self.Viewer2 = argument_[4]
        self.ser = argument_[5]
        self.curve = argument_[6]
        self.lineEdit_CurrentFrame = argument_[7]
        self.xPosition = argument_[8]
        self.img1 = argument_[9]
        self.xPositionAbs = argument_[10]
        self.yPositionAbs = argument_[11]
        self.xLaserPosition = argument_[12]
        self.yLaserPosition = argument_[13]
        self.fittingSlope = argument_[14]
        self.fittingIntercept = argument_[15]
        self.fittingSlopeY = argument_[16]
        self.fittingInterceptY = argument_[17]
        self.xPulse = argument_[18]
        self.yPulse = argument_[19]
        self.w = argument_[20]
        self.h = argument_[21]
        self.sleepPeriod = argument_[22]

        self.campareNum = 0
        self.xWay, self.yWay = 0, 0
        self.xWayNum, self.yWayNum = 0, 0
        global FinishedAutofocusFlag
        FinishedAutofocusFlag = False

        self.xStep = 800
        self.yStep = -800
        # # Block Laser
        # self.serialMove.ServoMovement(self.ser, -1)
        # time.sleep(0.5)
        # # Turn on LED
        # self.serialMove.changevoltage(self.ser, 1)
        # time.sleep(0.1)
        #
        # self.serialMove.movement(self.ser, 'X Axis', self.yPulse[0])
        # time.sleep(2)
        # self.serialMove.movement(self.ser, 'Y Axis', self.xPulse[0])
        # time.sleep(2)
        pass

    def __del__(self):
        self.working = False
        # self.wait()
        pass

    def timeInterval(self, pulse):
        if pulse <= 50:
            self.sleepTimeInterval = 0.3
            pass
        elif pulse <= 100:
            self.sleepTimeInterval = 0.55
            pass
        elif pulse > 100 and pulse >= 600:
            self.sleepTimeInterval = 0.55 + int(round(pulse/100)) * 0.3
            pass
        elif pulse <= 1500:
            self.sleepTimeInterval = 3
            pass
        elif pulse <= 2000:
            self.sleepTimeInterval = 3.5
            pass
        else:
            self.sleepTimeInterval = 5
            pass
        return self.sleepTimeInterval

    def run(self):
        # We can click "Quit Acquisition" Button which would chaneg the gobal varible "autoAcqFlag" to end current porcess
        while self.AutoAcqWorking and autoAcqFlag:
            frame = GetMVFrame(self.hcamera)
            x = frame.shape[1]
            y = frame.shape[0]
            Qframe = QImage(frame, x, y, x, QImage.Format_Grayscale8)
            pixmap = QPixmap(Qframe)
            self.Viewer2.setPixmap(pixmap)
            self.Viewer2.setScaledContents(True)  # 图片自适应

            if self.currentframe < self.TotalNum:
                # if we clicked "Stop acquisition" button we will stop current acquisition!!!
                global stopAutoAcqFlag
                if not stopAutoAcqFlag:
                    # judge whether it is in autofocus state

                    global focusingFlag
                    if focusingFlag:
                        print('Autofocusing!!!')
                        pass

                    else:
                        # judge whether finished data acquisition in one frame
                        global FinishedAutofocusFlag
                        if FinishedAutofocusFlag:
                            # 图相处理，添加更新位置坐标，以及脉冲的数量的txt文件
                            self.img1 = GetMVFrame(self.hcamera)
                            self.img3 = self.img1.copy()
                            self.Imgprocessor.imgSegment2(self.img3, 90, cv2.MORPH_ELLIPSE, (3, 3), 0.2, self.w, self.h)
                            time.sleep(0.1)
                            # self.imageTracingFlag = True
                            self.AcqNums = 0
                            self.xPosition = []
                            self.yPosition = []
                            self.xPositionAbs = []
                            self.yPositionAbs = []
                            self.xPulse = []
                            self.yPulse = []
                            self.position_shift = [0, 0]
                            os.chdir(
                                'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')

                            with open('Points need to be acquired.txt', 'r') as f:
                                pulse = f.readline()
                                while pulse:
                                    # print('data2:{}, type2:{}'.format(str2,type(str2)))
                                    x_tmp, y_tmp = [float(i) for i in pulse.split()]
                                    x_tmp = (x_tmp)
                                    y_tmp = (y_tmp)
                                    self.xPosition.append(x_tmp)
                                    self.yPosition.append(y_tmp)
                                    pulse = f.readline()
                                    pass
                                pass
                            with open('Points need to be acquired(abs).txt', 'r') as f:
                                pulse = f.readline()
                                while pulse:
                                    # print('data2:{}, type2:{}'.format(str2,type(str2)))
                                    x_tmp, y_tmp = [float(i) for i in pulse.split()]
                                    x_tmp = int(x_tmp)
                                    y_tmp = int(y_tmp)
                                    self.xPositionAbs.append(x_tmp)
                                    self.yPositionAbs.append(y_tmp)
                                    pulse = f.readline()
                                    pass
                                pass
                            with open('MotorPulse.txt', 'r') as f:
                                pulse = f.readline()
                                while pulse:
                                    # print('data2:{}, type2:{}'.format(str2,type(str2)))
                                    x_tmp, y_tmp = [float(i) for i in pulse.split()]
                                    x_tmp = int(x_tmp)
                                    y_tmp = int(y_tmp)
                                    # print(x_tmp)
                                    # print(y_tmp)
                                    self.xPulse.append(x_tmp)
                                    self.yPulse.append(y_tmp)
                                    pulse = f.readline()
                                    pass
                                pass

                            if len(self.xPosition):

                                self.cycleIndex += 1
                                os.chdir(
                                    'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
                                filename = str(self.cycleIndex) + 'Original_Image' + '.jpg'
                                image = Image.fromarray(self.img1, mode=None)
                                image.save(filename)

                                filename = str(self.cycleIndex) + 'Original_Image_Marked' + '.jpg'
                                image = Image.fromarray(self.img3, mode=None)
                                image.save(filename)

                                self.xshift = 0
                                self.yshift = 0

                                # Turn on LED
                                self.serialMove.changevoltage(self.ser, 1)
                                time.sleep(0.1)

                                # Block Laser
                                self.serialMove.ServoMovement(self.ser, -1)
                                time.sleep(0.6)

                                self.serialMove.movement(self.ser, 'X Axis', self.yPulse[0])
                                sleepPerid = self.timeInterval(abs(self.yPulse[0]))
                                time.sleep(sleepPerid)
                                # time.sleep(2.5)

                                self.serialMove.movement(self.ser, 'Y Axis', self.xPulse[0])
                                sleepPerid = self.timeInterval(abs(self.xPulse[0]))
                                time.sleep(sleepPerid)
                                # time.sleep(2.5)
                                FinishedAutofocusFlag = False
                                pass

                            elif len(self.xPosition) == 0:
                                print('Autofocusing!!!2')

                                lfx, lfy = 30, 30
                                rgx, rgy = int(self.w - 30), int(self.yLaserPosition - 15)
                                imgTemp = GetMVFrame(self.hcamera)

                                # _, thresh = cv2.threshold(imgTemp[lfy:rgy, lfx:rgx], 70, 255, cv2.THRESH_BINARY_INV)

                                # gradX = cv2.Sobel(imgTemp[lfy:rgy, lfx:rgx], ddepth=cv2.CV_32F, dx=1, dy=0)
                                # gradY = cv2.Sobel(imgTemp[lfy:rgy, lfx:rgx], ddepth=cv2.CV_32F, dx=0, dy=1)
                                # gradient = cv2.subtract(gradX, gradY)
                                # gradient = cv2.convertScaleAbs(gradient)  # 转换位深
                                # blurred = cv2.GaussianBlur(gradient, (3, 3), 0)
                                # _, thresh = (cv2.threshold(blurred, 210, 255, cv2.THRESH_BINARY))
                                # # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (10, 10))
                                # # closed = cv2.morphologyEx(thresh, cv2.MORPH_ELLIPSE, kernel)
                                # # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
                                # # closed = cv2.erode(closed, kernel, iterations=2)
                                # # thresh = closed

                                edges = cv2.Canny(imgTemp[lfy:rgy, lfx:rgx], 150, 255, L2gradient=False)
                                kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13))  # 定义结构元素的形状和大小
                                thresh = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)

                                kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))  # 定义矩形结构元素
                                opening = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)  # 梯度
                                print('np.sum(opening) is :{}'.format(np.sum(opening)))
                                if self.xStep >= 0:
                                    if np.sum(opening) >= 9000:
                                        self.serialMove.movement(self.ser, 'X Axis', 300)
                                        self.xWay += 300
                                        time.sleep(0.5)
                                        self._signal.emit(1)
                                        focusingFlag = True
                                        FinishedAutofocusFlag = False
                                        pass
                                    else:
                                        time.sleep(0.35)
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(abs(self.xStep))
                                        time.sleep(sleepPerid)
                                        pass
                                    pass

                                elif self.xStep < 0:
                                    if np.sum(opening) >= 20000:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        self._signal.emit(1)
                                        focusingFlag = True
                                        self.FishedRamanacquiredFlag = False
                                        pass
                                    else:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        # time.sleep(3)
                                        pass
                                    pass
                                pass
                            pass

                        else:
                            if self.FishedRamanacquiredFlag:
                                # finished Raman spectra acquisition in one frame
                                print('Finished Raman acquisition')

                                # self.serialMove.movement(self.ser, 'Y Axis', -600)
                                # self.yWay += -600
                                # time.sleep(3)

                                # start autofocus
                                lfx, lfy = 30, 30
                                rgx, rgy = int(self.yLaserPosition - 20), int(self.w - 30)
                                print(rgx, rgy)
                                imgTemp = GetMVFrame(self.hcamera)

                                # _, thresh = cv2.threshold(imgTemp[lfy:rgy, lfx:rgx], 70, 255, cv2.THRESH_BINARY_INV)

                                # gradX = cv2.Sobel(imgTemp[lfy:rgy, lfx:rgx], ddepth=cv2.CV_32F, dx=1, dy=0)
                                # gradY = cv2.Sobel(imgTemp[lfy:rgy, lfx:rgx], ddepth=cv2.CV_32F, dx=0, dy=1)
                                # gradient = cv2.subtract(gradX, gradY)
                                # gradient = cv2.convertScaleAbs(gradient)  # 转换位深
                                # blurred = cv2.GaussianBlur(gradient, (3, 3), 0)
                                # _, thresh = (cv2.threshold(blurred, 210, 255, cv2.THRESH_BINARY))
                                # # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (10, 10))
                                # # closed = cv2.morphologyEx(thresh, cv2.MORPH_ELLIPSE, kernel)
                                # # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
                                # # closed = cv2.erode(closed, kernel, iterations=2)
                                # # thresh = closed

                                edges = cv2.Canny(imgTemp[lfx:rgx, lfy:rgy], 150, 255, L2gradient=False)
                                kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13))  # 定义结构元素的形状和大小
                                thresh = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)

                                kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))  # 定义矩形结构元素
                                opening = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)  # 梯度

                                thresh1 = cv2.threshold(imgTemp[lfx:rgx, lfy:rgy], 210, 255, cv2.THRESH_BINARY)
                                # intensity = np.sum(np.sum(thresh1))
                                # _,self.thresh = (cv2.threshold(blurred, self.minThresh, self.maxThresh, cv2.THRESH_BINARY))

                                print('np.sum(opening) is :{}'.format(np.sum(opening)))
                                # print('intensity is :{}'.format(intensity))
                                if self.xStep >= 0 :
                                    if np.sum(opening) >= 9000:
                                        self.serialMove.movement(self.ser, 'X Axis', 350)
                                        time.sleep(0.5)
                                        self.xWay += 350
                                        self._signal.emit(1)
                                        focusingFlag = True
                                        self.FishedRamanacquiredFlag = False
                                        pass
                                    else:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        # time.sleep(3)
                                        pass
                                elif self.xStep < 0:
                                    if np.sum(opening) >= 20000:
                                        self.serialMove.movement(self.ser, 'X Axis', -1500)

                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(-1500)
                                        time.sleep(sleepPerid)
                                        self._signal.emit(1)
                                        focusingFlag = True
                                        self.FishedRamanacquiredFlag = False
                                        pass
                                    else:
                                        self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                        self.xWay += self.xStep
                                        sleepPerid = self.timeInterval(self.xStep)
                                        time.sleep(sleepPerid)
                                        # time.sleep(3)
                                        pass
                                    pass
                                pass
                            else:
                                # acquire Raman spectra
                                self.img2 = GetMVFrame(self.hcamera)
                                if self.AcqNums <= len(self.xPosition) - 1 and self.campareNum <= 15:
                                    self.position_shift = self.Imgprocessor.imagecompare(self.img1, self.img2,
                                                                            [int(self.xPositionAbs[self.AcqNums]),
                                                                             int(self.yPositionAbs[self.AcqNums])],
                                                                            [int(self.xLaserPosition),
                                                                             int(self.yLaserPosition)])

                                    xTemp = self.xPositionAbs[self.AcqNums] + self.position_shift[0]
                                    yTemp = self.yPositionAbs[self.AcqNums] + self.position_shift[1]

                                    lfxposInsrc, lfyposInsrc = int(self.xPositionAbs[self.AcqNums]) - 7, int(self.yPositionAbs[self.AcqNums]) - 10
                                    rixposInsrc, riyposInsrc = int(self.xPositionAbs[self.AcqNums]) + 7, int(self.yPositionAbs[self.AcqNums]) + 10

                                    lfxposIntar, lfyposIntar = int(xTemp) - 7, int(yTemp) - 10
                                    rixposIntar, riyposIntar = int(xTemp) + 7, int(yTemp) + 10

                                    # *0.87
                                    # self.sourceGrayValue = np.sum(self.img1[lfyposInsrc:riyposInsrc, lfxposInsrc:rixposInsrc])
                                    # self.targetGaryValue = np.sum(self.img2[lfyposIntar:riyposIntar, lfxposIntar:rixposIntar])

                                    # # *0.8
                                    # self.sourceGrayValue = np.max(
                                    #     self.img1[lfyposInsrc:riyposInsrc, lfxposInsrc:rixposInsrc])
                                    # self.targetGaryValue = np.max(
                                    #     self.img2[lfyposIntar:riyposIntar, lfxposIntar:rixposIntar])

                                    edges = cv2.Canny(self.img1[lfyposInsrc:riyposInsrc, lfxposInsrc:rixposInsrc], 150, 255, L2gradient=False)
                                    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13))  # 定义结构元素的形状和大小
                                    thresh = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)

                                    # juage whether it is in focus

                                    # if self.targetGaryValue <= self.sourceGrayValue * 0.8:
                                    # if sample is out of focus, we need to do autofocus to make sure
                                    # the sample is right on the focus plane and if campare num is more than 15
                                    # which means template matching don't work, we also need to do autofocus again
                                    print('sum of thresh is:{}'.format(np.sum(thresh)))
                                    print('campareNum is:{}'.format(self.campareNum))

                                    if np.sum(thresh) <= 1500:
                                        # self.AutoFoucs()
                                        lfx, lfy = 30, 30
                                        rgx, rgy = int(self.yLaserPosition - 20), int(self.w - 30)
                                        imgTemp = GetMVFrame(self.hcamera)
                                        # _, thresh = cv2.threshold(imgTemp[lfy:rgy, lfx:rgx], 70, 255,
                                        #                           cv2.THRESH_BINARY_INV)

                                        # gradX = cv2.Sobel(imgTemp[lfy:rgy, lfx:rgx], ddepth=cv2.CV_32F, dx=1, dy=0)
                                        # gradY = cv2.Sobel(imgTemp[lfy:rgy, lfx:rgx], ddepth=cv2.CV_32F, dx=0, dy=1)
                                        # gradient = cv2.subtract(gradX, gradY)
                                        # gradient = cv2.convertScaleAbs(gradient)  # 转换位深
                                        # blurred = cv2.GaussianBlur(gradient, (3, 3), 0)
                                        # _, thresh = (cv2.threshold(blurred, 21, 255, cv2.THRESH_BINARY))
                                        # # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (10, 10))
                                        # # closed = cv2.morphologyEx(thresh, cv2.MORPH_ELLIPSE, kernel)
                                        # # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
                                        # # closed = cv2.erode(closed, kernel, iterations=2)
                                        # # thresh = closed

                                        edges = cv2.Canny(imgTemp[lfx:rgx, lfy:rgy], 150, 255, L2gradient=False)
                                        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13))  # 定义结构元素的形状和大小
                                        thresh = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)

                                        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))  # 定义矩形结构元素
                                        opening = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)  # 梯度
                                        # print('np.sum(opening) is :{}'.format(np.sum(opening)))

                                        thresh1 = cv2.threshold(imgTemp[lfx:rgx, lfy:rgy], 210, 255, cv2.THRESH_BINARY)
                                        # intensity = np.sum(np.sum(np.sum(thresh1)))

                                        if self.xStep >= 0:
                                            if np.sum(opening) >= 9000:
                                                self.serialMove.movement(self.ser, 'X Axis', 350)
                                                self.xWay += 350
                                                time.sleep(0.5)
                                                self._signal.emit(1)
                                                focusingFlag = True
                                                pass
                                            else:
                                                self.serialMove.movement(self.ser, 'X Axis', 1000)
                                                self.xWay += 1000
                                                time.sleep(3)
                                                pass
                                            pass
                                        elif self.xStep < 0:
                                            if np.sum(opening) >= 20000:
                                                self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                                                self.xWay += self.xStep
                                                sleepPerid = self.timeInterval(self.xStep)
                                                time.sleep(sleepPerid)
                                                self._signal.emit(1)
                                                focusingFlag = True
                                                self.FishedRamanacquiredFlag = False
                                                pass
                                            else:
                                                self.serialMove.movement(self.ser, 'X Axis', self.xStep)

                                                self.xWay += self.xStep
                                                sleepPerid = self.timeInterval(self.xStep)
                                                time.sleep(sleepPerid)
                                                # time.sleep(3)
                                                pass
                                            pass
                                        self.campareNum = 0
                                        pass
                                    # sample is not out of focus
                                    else:

                                        if (xTemp - self.xLaserPosition) ** 2 + (
                                                yTemp - self.yLaserPosition) ** 2 <= 6:

                                            # Turn off LED
                                            self.serialMove.changevoltage(self.ser, -1)
                                            time.sleep(0.1)

                                            # send in Laser
                                            self.serialMove.ServoMovement(self.ser, 1)
                                            time.sleep(0.3)

                                            # print('Start to acquire Raman spectra!!!')
                                            # Acquire Raman spectra
                                            img = self.camera.capture()
                                            time.sleep(self.sleepPeriod*1.2)
                                            rows = img.shape[0]
                                            sp = np.sum(img, axis=0) / rows

                                            # self.curve.setData(sp)
                                            # curr_time = datetime.datetime.now()
                                            # time_str = datetime.datetime.strftime(curr_time, '%Y_%m_%d_%H_%M_%S')
                                            #
                                            # filename = str(time_str) + '.txt'
                                            # os.chdir(
                                            #     'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\RamanSpectra')
                                            # np.savetxt(filename, sp)
                                            self._RamanSignal.emit(sp)

                                            self.currentframe += 1
                                            # self.lineEdit_CurrentFrame.setText(str(self.currentframe))



                                            # Turn on LED
                                            self.serialMove.changevoltage(self.ser, 1)
                                            time.sleep(0.1)

                                            # Block Laser
                                            # time.sleep(0.3)
                                            self.serialMove.ServoMovement(self.ser, -1)
                                            time.sleep(0.6)



                                            if self.AcqNums == len(self.xPosition) - 1:
                                                self.AcqNums += 1
                                                self.FishedRamanacquiredFlag = True
                                                # time.sleep(0.5)
                                                pass
                                            else:
                                                self.AcqNums += 1
                                                self.serialMove.movement(self.ser, 'X Axis', self.yPulse[self.AcqNums])
                                                sleepPerid = self.timeInterval(self.yPulse[self.AcqNums])
                                                time.sleep(sleepPerid)
                                                # time.sleep(2.5)
                                                self.serialMove.movement(self.ser, 'Y Axis', self.xPulse[self.AcqNums])
                                                sleepPerid = self.timeInterval(self.xPulse[self.AcqNums])
                                                time.sleep(sleepPerid)
                                                # time.sleep(2.5)
                                                pass
                                            self.campareNum = 0
                                            pass
                                        else:
                                            # print('Keep moving!!!')
                                            self.xshift = int(
                                                (self.xLaserPosition - xTemp) * self.fittingSlopeY + self.fittingInterceptY)
                                            self.yshift = int(
                                                (self.yLaserPosition - yTemp) * self.fittingSlope + self.fittingIntercept)
                                            self.serialMove.movement(self.ser, 'X Axis', self.yshift)
                                            sleepPerid = self.timeInterval(self.yshift)
                                            time.sleep(sleepPerid)
                                            # time.sleep(2)
                                            self.serialMove.movement(self.ser, 'Y Axis', self.xshift)
                                            sleepPerid = self.timeInterval(self.xshift)
                                            time.sleep(sleepPerid)
                                            # time.sleep(2)
                                            self.campareNum += 1
                                            pass
                                        pass
                                    # juage whether it is in focus

                                    pass

                                else:
                                    self._signal.emit(1)
                                    focusingFlag = True
                                    self.campareNum = 0
                                    pass
                                pass
                            pass
                        # judge whether finished data acquisition in one frame
                        pass

                    # judge whether it is in autofocus state

                    # To aviod damage the objective
                    if abs(self.xWay) >= 15500 and not focusingFlag:
                        # self.serialMove.movement(self.ser, 'X Axis', round(-self.xWay/4))
                        # self.xWay = 0
                        # time.sleep(10)
                        self.xWay = 0
                        self.xWayNum += 1
                        if self.xWayNum >= 12 and not focusingFlag:
                            self.xWayNum = 0
                            self.serialMove.movement(self.ser, 'Y Axis', -4000)
                            self.yWay += -4000
                            time.sleep(6)
                            # self.serialMove.movement(self.ser, 'Y Axis', -4000)
                            # self.yWay += -4000
                            # time.sleep(5)
                            if self.xStep == 800:
                                self.xStep = -1500
                                pass
                            elif self.xStep == -1500:
                                self.xStep = 800
                                pass
                            self._signal.emit(1)
                            focusingFlag = True
                            pass
                        print('xWayNum is:{}'.format(self.xWayNum))
                        pass

                    if abs(self.yWay) >= 15500 and not focusingFlag:
                        # self.serialMove.movement(self.ser, 'Y Axis', round(-self.yWay/4))
                        # self.yWay = 0
                        # time.sleep(10)
                        self.yWay = 0
                        self.yWayNum += 1
                        if self.yWayNum == 12 and not focusingFlag:
                            self.yWayNum = 0
                            self.serialMove.movement(self.ser, 'X Axis', 1500)
                            self.xWay += 1500
                            time.sleep(4)
                            if self.yStep == -800:
                                self.yStep = 1500
                                pass
                            elif self.yStep == 1500:
                                self.yStep = -800
                                pass
                            self._signal.emit(1)
                            focusingFlag = True
                            pass
                        print('yWayNum is:{}'.format(self.yWayNum))
                        # self.serialMove.movement(self.ser, 'X Axis', self.xStep)
                        # time.sleep(3)
                        # self.xWay += self.xStep
                        # self.yStep = -self.yStep
                        # self._signal.emit(1)
                        # focusingFlag = True
                        pass
                    # To aviod damage the objective
                    # print('self.xWay is: {}'.format(self.xWay))
                    pass

                else:
                    # print('Stop acquisition!!!!')
                    pass
                # if we clicked "Stop acquisition" button we will stop current acquisition!!!

            else:
                self.AutoAcqWorking = False
                pass
            # img = self.fun.capture()
            # self._signal.emit(img)
            time.sleep(0.5)
            pass
        pass

    pass

# UI thread
#
class Action(QMainWindow,Ui_MainWindow):

    camera = ''
    img = np.ndarray
    # oriFocuseFlag = pyqtSignal()
    _finishedAutofocus = pyqtSignal()
    def __init__(self):
        super().__init__()
        self.camera_id = 0
        self.hCamera = 0
        self.setupUi(self)
        self.initUI()
        self.serialParameter()
        self.oriNum = 0
        self.currentframe = 0
        self.saveFlag = 0
        self.saveFlag2 = 0
        self.serialFlag = 0
        self.mousemoveflag = False
        self.imageTracingFlag = False
        self.autoRamanspec = False
        self.flag1 = False
        self.focusFlag = False
        self.focusingFlag = False
        # logger = logging.getLogger(__name__)
        pass

    def initUI(self):
        # ZWO
        self.check_camera_connection()
        self.pushButton_Scan.clicked.connect(self.showCameraID)
        self.pushButton_Open.clicked.connect(self.openCamera)
        self.pushButton_Quit.clicked.connect(self.Quit)
        self.pushButton_Cooling.clicked.connect(self.cooling)
        self.pushButton_Sanp.clicked.connect(self.graphSnap)
        self.pushButton_Start.clicked.connect(self.living)
        self.pushButton_Apply.clicked.connect(self.setBin)
        self.lineEdit_Exp.editingFinished.connect(self.setExp)
        self.lineEdit_Gain.editingFinished.connect(self.setGain)
        self.lineEdit_Gammar.editingFinished.connect(self.setGammar)
        self.lineEdit_TargetTemp.editingFinished.connect(self.setTargetTemp)
        self.pushButton_ROI.clicked.connect(self.editROI)
        self.pushButton_Full.clicked.connect(self.editROI)
        self.pushButton_SetFormat.clicked.connect(self.setROI)
        self.pushButton_mode.clicked.connect(self.changeMode)
        self.pushButton_Stop.clicked.connect(self.stop)
        self.pushButton_Init.clicked.connect(self.serialInit)
        self.pushButton_Close2.clicked.connect(self.serialClose)
        self.pushButton_Forward.clicked.connect(self.moveForward)
        self.pushButton_Backward.clicked.connect(self.moveBackward)
        self.Viewer.mouseMoveEvent = self.getPos
        self.Viewer.setCursor(Qt.CrossCursor)
        p = self.widget.addPlot(title='Spectrum')
        self.curve = p.plot(pen='y')


        self.Timer = QTimer()
        self.Timer.timeout.connect(self.TimerOutFun)

        # Other Camera
        self.pushButton_Start_Pi.clicked.connect(self.livingPi)
        self.pushButton_Stop_Pi.clicked.connect(self.stopPi)
        self.lineEdit_Exp_Pi.editingFinished.connect(self.setExpPi)
        self.pushButton_Snap_Pi.clicked.connect(self.graphSnapPi)
        self.pushButton_ChangeROI.clicked.connect(self.MVChangeResolution)
        self.Viewer2.mouseMoveEvent = self.getPos2
        self.Viewer2.setCursor(Qt.CrossCursor)
        self.pushButton_Path.clicked.connect(self.SelectPath)
        self.lineEdit_Path_Pi.setText(r'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running '
                                      r'cache\coordinate')

        # improcess
        self.pushButton_Improcess.clicked.connect(self.jumpTo1)
        # self.pushButton_Acquire.clicked.connect(self.acquire)
        self.pushButton_Automatic.clicked.connect(self.acquire2)
        self.pushButton_AutoFocus.clicked.connect(self.AutoFoucs)
        self.pushButton_AcquireTimeseries.clicked.connect(self.acquire3)

        # self.pushButton_Automatic.clicked.connect(self.jumpTo2)
        self.show()
        #
        self.pushButton_LaserIn.clicked.connect(self.ServoMovement)
        self.pushButton_LaserOut.clicked.connect(self.ServoMovement)
        self.pushButton_TurnOn.clicked.connect(self.changevoltage)
        self.pushButton_TurnOff.clicked.connect(self.changevoltage)
        self.pushButton_ChangeTimeInterval.clicked.connect(self.ChangeTimeInterval)
        self.pushButton_QuitAcq.clicked.connect(self.changeAutoAcqFlag)
        self.pushButton_StopAcq.clicked.connect(self.changeAutoAcqFlag)
        self.pushButton_TestPositioning.clicked.connect(self.testPositioning)

        self.lineEdit_Step.setText('20')
        self.lineEdit_TotalNumbers.setText('20')
        self.lineEdit_PointsToAutofocus.setText('5')
        self.lineEdit_TimeSeries.setText('1000000, 500000, 250000, 100000, 80000, 50000, 25000, 10000, 5000')
        self.LineFigure = Figure_Canvas()
        # 在GUI的groupbox中创建一个布局，用于MyFigure类的实例
        self.LineFigureLayout = QGridLayout(self.groupBox_FittingResult)
        self.LineFigureLayout.addWidget(self.LineFigure)
        #
        self.Imgprocessor = ImgProcess()
        self.Serialmovement = SerialPort()

        # self.sleepPeriod = 1
        global timeInter1
        timeInter1 = 0.2
        global timeInter2
        timeInter2 = 0.2
        pass

    def getPos(self, event):
        x = event.pos().x()
        y = event.pos().y()
        self.lineEdit_XPosition.setText(str(x))
        self.lineEdit_YPosition.setText(str(y))
        pass

    def getPos2(self, event):
        x = event.pos().x()
        y = event.pos().y()
        self.lineEdit_XPositionPi.setText(str(x))
        self.lineEdit_YPositionPi.setText(str(y))
        pass

    def jumpTo1(self):
        self.ui = Action2()
        self.ui.show()
        pass

    def serialParameter(self):
        port_list = list(serial.tools.list_ports.comports())
        for num in range(len(port_list)):
            portlist = list(port_list[num])
            self.comboBox_SerialPort.addItem(portlist[num])
            pass
        pass

    def check_camera_connection(self):
        # ZWO Camera
        check_environment()
        camNums = asi.get_num_cameras()

        if camNums == 0:
            print('No cameras found')
            # sys.exit(0)


        # cameras_found = asi.list_cameras()  # Models names of the connected cameras

        # if camNums == 1:
            # camera_id = 0
            # print('Found one camera: %s' % cameras_found[0])
            # pass
        #
        # else:
        #     print('Found %d cameras' % camNums)
        #     for n in range(camNums):
        #         print('  %d: %s' % (n, cameras_found[n]))
        #         pass

            # TO DO: allow user to select a camera
            # camera_id = 0
            # print('Using #%d: %s' % (camera_id, cameras_found[camera_id]))
            pass
        # camera = asi.Camera(camera_id)

        # Other Camera
        DevList = mvsdk.CameraEnumerateDevice()
        nDev = len(DevList)
        if nDev < 1:
            print("No MVcamera was found!")
            pass
        # else:
            # for i, DevInfo in enumerate(DevList):
                # print("{}: {} {}".format(i, DevInfo.GetFriendlyName(), DevInfo.GetPortType()))
            # i = 0 if nDev == 1 else int(input("Select camera: "))
            # DevInfo = DevList[i]
            # print(DevInfo)

            # 打开相机
            # hCamera = 0
            # try:
            #     hCamera = mvsdk.CameraInit(DevInfo, -1, -1)
            # except mvsdk.CameraException as e:
            #     print("CameraInit Failed({}): {}".format(e.error_code, e.message))
            # pass
        pass

    def showCameraID(self):
        # ZWO Camera
        num = asi.get_num_cameras()
        found = asi.list_cameras()
        if num == 1:
            self.comboBox_CameraID.addItem(str(found[num-1]))
            self.camera_id = 0
            pass
        else:
            for i in num:
                self.comboBox_CameraID.addItem(str(found[i-1]))
                pass
            self.camera_id = 0
            pass

        # Other Camera (Pi camera or MindVision)

        DevList = mvsdk.CameraEnumerateDevice()
        nDev = len(DevList)
        #
        # print(DevList)
        # print(nDev)
        # for i, DevInfo in enumerate(DevList):
        #     DevInfo = DevList[i]
        #     self.comboBox_CameraID2.addItem(str(DevInfo.GetPortType))
        #     pass
        # self.mvcamera_id = 0
        # print(DevInfo)

        if nDev == 1:
            self.comboBox_CameraID_Pi.addItem(str(DevList[nDev-1].GetProductName()))
            pass
        else:
            for i in nDev:
                self.comboBox_CameraID_Pi.addItem(str(DevList[i-1].GetProductName()))
                pass
            pass
        self.DevInfo = DevList[0]
        pass

    def openCamera(self):
        # ZWO Camera
        self.Image_num = 0
        self.camera = asi.Camera(self.camera_id)
        # camera_info = self.camera.get_camera_property()
        # controls = self.camera.get_controls()
        #
        # for cn in sorted(controls.keys()):
        #     print('    %s:' % cn)
        #
        #     for k in sorted(controls[cn].keys()):
        #         print('        %s: %s' % (k, repr(controls[cn][k])))
        #         pass
        #     pass
        self.camera.set_control_value(asi.ASI_GAIN, 150)
        self.lineEdit_Gain.setText('150')
        self.camera.set_control_value(asi.ASI_EXPOSURE, 30000)
        self.lineEdit_Exp.setText('30000')
        self.camera.set_control_value(asi.ASI_WB_B, 99)
        self.camera.set_control_value(asi.ASI_WB_R, 75)
        self.camera.set_control_value(asi.ASI_GAMMA, 50)
        self.lineEdit_Gammar.setText('50')
        self.camera.set_control_value(asi.ASI_BRIGHTNESS, 50)
        self.camera.set_control_value(asi.ASI_FLIP, 0)
        self.camera.set_image_type(asi.ASI_IMG_RAW8)
        self.comboBox_ImageType.addItem('ASI_IMG_RAW8')
        self.comboBox_ImageType.addItem('ASI_IMG_RAW16')
        self.comboBox_BIN.addItem('BIN1')
        self.comboBox_BIN.addItem('BIN2')
        self.comboBox_BIN.addItem('BIN3')
        self.comboBox_BIN.addItem('BIN4')

        self.lineEdit_ROIHeight.setText('2080')
        self.lineEdit_ROIWidth.setText('3096')
        self.lineEdit_StartPosX.setText('1')
        self.lineEdit_StartPosY.setText('1')

        self.lineEdit_EndPosX.setText('3096')
        self.lineEdit_EndPosY.setText('2080')

        self.lineEdit_CurrentFrame.setText('1')
        self.lineEdit_Mode.setText('Image')

        self.thread1 = ImageAcqThread(self.camera)
        self.thread1._signal.connect(self.DispImg)
        self.Timer.start(1)
        self.thread1.start()
        self.timelb = time.perf_counter()

        # MV Camera
        self.hCamera = mvsdk.CameraInit(self.DevInfo, -1, -1)
        cap = mvsdk.CameraGetCapability(self.hCamera)
        self.monoCamera = (cap.sIspCapacity.bMonoSensor != 0)

        # 黑白相机让ISP直接输出MONO数据，而不是扩展成R=G=B的24位灰度
        if self.monoCamera:
            mvsdk.CameraSetIspOutFormat(self.hCamera, mvsdk.CAMERA_MEDIA_TYPE_MONO8)
            pass
        else:
            mvsdk.CameraSetIspOutFormat(self.hCamera, mvsdk.CAMERA_MEDIA_TYPE_BGR8)
            pass

        mvsdk.CameraSetTriggerMode(self.hCamera, 0)
        mvsdk.CameraSetAeState(self.hCamera, 0)
        mvsdk.CameraSetExposureTime(self.hCamera, 30 * 1000)
        self.lineEdit_Exp_Pi.setText('30000')

        PImageResolution = mvsdk.CameraGetResolutionForSnap(self.hCamera)
        width = 160
        height = 120
        widthOffset = 295
        # heightOffset = 165
        heightOffset = 140
        PImageResolution.iIndex = 0xff
        PImageResolution.iWidth = (width)
        PImageResolution.iWidthFOV = (width)
        PImageResolution.iHeight = (height)
        PImageResolution.iHeightFOV = (height)
        PImageResolution.iHOffsetFOV = (widthOffset)
        PImageResolution.iVOffsetFOV = (heightOffset)
        mvsdk.CameraSetImageResolution(self.hCamera, PImageResolution)
        # 让SDK内部取图线程开始工作

        mvsdk.CameraPlay(self.hCamera)

        self.lineEdit_ROIWidthPi.setText(str(width))
        self.lineEdit_ROIHeightPi.setText(str(height))
        self.lineEdit_ROIWidthOffsetPi.setText(str(widthOffset))
        self.lineEdit_ROIHeightOffsetPi.setText(str(heightOffset))
        self.lineEdit_Resolution_Pi.setText(str(width)+' x '+str(height))
        self.lineEdit_Gain_Pi.setText('Low')
        # MVResolution = ['640*480','560*420','480*360','400*300','320*240','240*180','160*120']
        # self.comboBox_Resolution.addItems(MVResolution)

        self.thread2 = ImageAcqThread2(self.hCamera)
        self.thread2._signal.connect(self.DispImg2)
        self.thread2.start()

        tt = self.Imgprocessor.LoadImageProcessParam()
        self.xLaserPosition = tt[0][0]
        self.yLaserPosition = tt[0][1]
        self.fittingSlope = tt[1][0]
        self.fittingIntercept = tt[1][1]
        self.fittingSlopeY = tt[2][0]
        self.fittingInterceptY = tt[2][1]
        pass

    def cooling(self):
        if self.lineEdit_TargetTemp.text() != '':
            self.camera.set_control_value(asi.ASI_COOLER_ON, True)
            self.camera.set_control_value(asi.ASI_TARGET_TEMP, int(self.lineEdit_TargetTemp.text()))
            pass
        else:
            QMessageBox.warning(self, '提示', '未设置目标温度')
            pass
        temp = int(self.lineEdit_TargetTemp.text())
        self.camera.set_control_value(asi.ASI_TEMPERATURE, temp)
        pass

    def DispImg(self, img):
    # if self.lineEdit_Mode.text() == 'Image':
        x = img.shape[1]
        y = img.shape[0]
        if self.comboBox_ImageType.currentText() == 'ASI_IMG_RAW8':
            frame = QImage(img, x, y, x, QImage.Format_Grayscale8)
            pass
        else:
            # temp = (img-img.min())
            # print(temp.max())
            # img1 = temp/temp.max()*255
            # print(img1.max())
            # img1.astype(np.uint8)
            frame = QImage(img, x, y, QImage.Format_RGB16)
            pass
        pixmap = QPixmap(frame)
        self.Viewer.setPixmap(pixmap)
        self.Viewer.setScaledContents(True) # 图片自适应

        self.lcdNumber_Width.display(x)
        self.lcdNumber_Height.display(y)
        # pass

    # elif self.lineEdit_Mode.text() == 'Spectrum':
        rows = img.shape[0]
        sp = np.sum(img, axis=0)/rows
        # print('%d' %sp.shape[0])
        self.curve.setData(sp)
        # pass

        self.Image_num += 1

        if self.Image_num % 10 == 9:
            frame_rate = 10/(time.perf_counter() - self.timelb)
            self.lcdNumber_FrameRate.display(frame_rate)
            self.timelb = time.perf_counter()
            # self.Image_num = 0
            pass

        if self.saveFlag == 1:
            mode = None
            # if self.comboBox_ImageType.currentText() == 'ASI_IMG_RAW16':
            #     mode = 'I;16'
            #     pass
            #
            # filename = str(self.savedNum)+'.jpg'
            # image = Image.fromarray(img, mode=mode)
            # image.save(filename)

            rows = img.shape[0]
            sp = np.sum(img, axis=0) / rows

            curr_time = datetime.datetime.now()
            time_str = datetime.datetime.strftime(curr_time, '%Y_%m_%d_%H_%M_%S')
            # filename = str(time_str) + '.txt'

            filename = str(self.savedNum)+'_'+time_str+'.txt'
            np.savetxt(filename, sp)

            self.curve.setData(sp)
            self.savedNum += 1
            self.lineEdit_CurrentFrame.setText(str(self.savedNum))
            if int(self.lineEdit_FrameNum.text()) == self.savedNum:
                self.saveFlag = 0
                self.label_CurrentFrame.setEnabled(False)
                self.lineEdit_CurrentFrame.setEnabled(False)
                self.lineEdit_CurrentFrame.setText('1')
                pass
            pass
            pass
        self.img = img
        pass

    def DispImg2(self, frame):

    # if self.lineEdit_Mode.text() == 'Image':
    #     frame2 = frame.copy()
        x = frame.shape[1]
        y = frame.shape[0]
        # cv2.circle(frame2, (int(self.xLaserPosition), int(self.yLaserPosition)), 2, (0, 255, 0), 2)
        Qframe = QImage(frame, x, y, x, QImage.Format_Grayscale8)
        pixmap = QPixmap(Qframe)
        self.Viewer2.setPixmap(pixmap)
        self.Viewer2.setScaledContents(True) # 图片自适应

        if self.saveFlag2 == 1:
            mode = None
            # t = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime())
            # filename = str(t)+'.jpg'
            filename = 'OriginalImage'+'.jpg'
            image = Image.fromarray(frame, mode=mode)
            image.save(filename)
            self.saveFlag2 = 0
        pass

    # def GetMVFrame(self):
    #
    #     cap = mvsdk.CameraGetCapability(self.hCamera)
    #     # 计算RGB buffer所需的大小，这里直接按照相机的最大分辨率来分配
    #     FrameBufferSize = cap.sResolutionRange.iWidthMax * cap.sResolutionRange.iHeightMax * 1
    #
    #     # 分配RGB buffer，用来存放ISP输出的图像
    #     # 备注：从相机传输到PC端的是RAW数据，在PC端通过软件ISP转为RGB数据（如果是黑白相机就不需要转换格式，但是ISP还有其它处理，所以也需要分配这个buffer）
    #     pFrameBuffer = mvsdk.CameraAlignMalloc(FrameBufferSize, 16)
    #
    #     pRawData, FrameHead = mvsdk.CameraGetImageBuffer(self.hCamera, 200)
    #     mvsdk.CameraImageProcess(self.hCamera, pRawData, pFrameBuffer, FrameHead)
    #     mvsdk.CameraReleaseImageBuffer(self.hCamera, pRawData)
    #
    #     # windows下取到的图像数据是上下颠倒的，以BMP格式存放。转换成opencv则需要上下翻转成正的
    #     # linux下直接输出正的，不需要上下翻转
    #     if platform.system() == "Windows":
    #         mvsdk.CameraFlipFrameBuffer(pFrameBuffer, FrameHead, 1)
    #
    #     # 此时图片已经存储在pFrameBuffer中，对于彩色相机pFrameBuffer=RGB数据，黑白相机pFrameBuffer=8位灰度数据
    #     # 把pFrameBuffer转换成opencv的图像格式以进行后续算法处理
    #     frame_data = (mvsdk.c_ubyte * FrameHead.uBytes).from_address(pFrameBuffer)
    #     frame = np.frombuffer(frame_data, dtype=np.uint8)
    #
    #     frame = frame.reshape((FrameHead.iHeight, FrameHead.iWidth))
    #     return frame

    # show frame rate
    def TimerOutFun(self):
        self.camera.get_controls()
        self.lineEdit_CurrentTemp.setText(str(self.camera.get_control_value(asi.ASI_TEMPERATURE)[0]/10))
        pass

    def graphSnap(self):
        self.label_CurrentFrame.setEnabled(True)
        self.lineEdit_CurrentFrame.setEnabled(True)
        self.saveFlag = 1
        self.savedNum = 0

        if self.lineEdit_FrameNum.text() == '':
            QMessageBox.warning('Please input the number you need to require!!!')
            pass
        else:
            if self.lineEdit_Path.text() == '':
                FolderPath = filedialog.askdirectory()
                self.lineEdit_Path.setText(FolderPath)
                # CurrentPath = os.getcwd()
                os.chdir(FolderPath)
                pass
            else:
                FolderPath = self.lineEdit_Path.text()
                os.chdir(FolderPath)
                pass
            pass
        pass

    def graphSnapPi(self):
        self.saveFlag2 = 1
        if self.lineEdit_Path_Pi.text() == '':
            FolderPath = filedialog.askdirectory()
            self.lineEdit_Path_Pi.setText(FolderPath)
            # CurrentPath = os.getcwd()
            os.chdir(FolderPath)
            pass
        else:
            FolderPath = self.lineEdit_Path_Pi.text()
            os.chdir(FolderPath)
            pass
        pass

    def living(self):
        global working
        working = True
        self.pushButton_Start.setEnabled(False)
        self.thread1.start()
        pass

    def livingPi(self):
        global working2
        working2 = True
        self.pushButton_Start_Pi.setEnabled(False)
        self.thread2.start()
        pass

    def setExp(self):
        self.camera.set_control_value(asi.ASI_EXPOSURE
                                      , int(self.lineEdit_Exp.text()))
        print('修改后的数值是：%s' %(self.lineEdit_Exp.text()))
        pass

    def setExpPi(self):
        mvsdk.CameraSetExposureTime(self.hCamera, int(self.lineEdit_Exp_Pi.text()))
        print('修改后的数值是：%s' %(self.lineEdit_Exp_Pi.text()))
        pass

    def setGain(self):
        self.camera.set_control_value(asi.ASI_GAIN, int(self.lineEdit_Gain.text()))
        print('修改后的数值是：%s' %(self.lineEdit_Gain.text()))
        pass

    def setGammar(self):
        self.camera.set_control_value(asi.ASI_GAMMA, int(self.lineEdit_Gammar.text()))
        print('修改后的数值是：%s' %(self.lineEdit_Gammar.text()))
        pass

    def setTargetTemp(self):
        # self.camera.set_control_value(asi.ASI_TARGET_TEMP, int(self.lineEdit_TargetTemp.text()))
        print('修改后的数值是：%s' %(self.lineEdit_TargetTemp.text()))
        pass

    def setBin(self):
        temp = self.comboBox_BIN.currentText()
        if temp == 'BIN1':
            Bin = 1
            pass
        elif temp == 'BIN2':
            Bin = 2
            pass
        elif temp == 'BIN3':
            Bin = 3
            pass
        else:
            Bin = 4
            pass

        tempdata = self.comboBox_ImageType.currentText()

        if tempdata == 'ASI_IMG_RAW8':
            imageType = 0
            pass
        elif tempdata == 'ASI_IMG_RAW16':
            imageType = 2
            pass

        oRoiValue = self.camera.get_roi_format()
        WidthNew = int(oRoiValue[0] * oRoiValue[2] / Bin / 8) * 8
        self.lineEdit_ROIWidth.setText(str(WidthNew))
        self.lineEdit_EndPosX.setText(str(WidthNew))
        HeightNew = int(oRoiValue[1] * oRoiValue[2] / Bin / 8) * 8
        self.lineEdit_ROIHeight.setText(str(HeightNew))
        self.lineEdit_EndPosY.setText(str(HeightNew))
        self.camera.set_roi_format(WidthNew, HeightNew, Bin, imageType)

        oStartPos = self.camera.get_roi_start_position()
        widthStart = int(oStartPos[0] * oRoiValue[2] / Bin)
        heightStart = int(oStartPos[1] * oRoiValue[2] / Bin)
        self.camera.set_roi_start_position(widthStart,heightStart)
        pass

    def editROI(self):
        if self.sender() == self.pushButton_ROI:
            self.lineEdit_StartPosX.setEnabled(True)
            self.lineEdit_StartPosY.setEnabled(True)
            self.lineEdit_EndPosX.setEnabled(True)
            self.lineEdit_EndPosY.setEnabled(True)
            self.pushButton_SetFormat.setEnabled(True)
            pass
        elif self.sender() == self.pushButton_Full:
            oRoiValue = self.camera.get_roi_format()

            self.lineEdit_StartPosX.setEnabled(False)
            self.lineEdit_StartPosX.setText('1')
            self.lineEdit_StartPosY.setEnabled(False)
            self.lineEdit_StartPosY.setText('1')

            if oRoiValue[2] == 1:
                width = 3096
                height = 2080
                pass
            elif oRoiValue[2] == 2:
                width = 1544
                height = 1040
                pass
            elif oRoiValue[2] == 3:
                width = 1024
                height = 688
                pass
            elif oRoiValue[2] == 4:
                width = 768
                height = 520
                pass

            self.lineEdit_EndPosX.setEnabled(False)
            self.lineEdit_EndPosX.setText(str(width))
            self.lineEdit_EndPosY.setEnabled(False)
            self.lineEdit_EndPosY.setText(str(height))
            self.lineEdit_ROIWidth.setText(str(width))
            self.lineEdit_ROIHeight.setText(str(height))
            self.pushButton_SetFormat.setEnabled(False)
            pass
        pass

    def setROI(self):
        xStart = int(self.lineEdit_StartPosX.text())
        yStart = int(self.lineEdit_StartPosY.text())

        xEnd = int(self.lineEdit_EndPosX.text())
        yEnd = int(self.lineEdit_EndPosY.text())

        width = int((xEnd - xStart + 1) / 8) * 8
        height = int((yEnd - yStart + 1) / 2) * 2

        oRoiValue = self.camera.get_roi_format()

        self.lineEdit_ROIWidth.setText(str(width))
        self.lineEdit_ROIHeight.setText(str(height))

        self.camera.set_roi_format(width,height,oRoiValue[2],oRoiValue[3])
        self.camera.set_roi_start_position(xStart, yStart)
        pass

    def changeMode(self):
        if self.lineEdit_Mode.text() == 'Image':
            self.lineEdit_Mode.setText('Spectrum')
            self.tabWidget.setCurrentIndex(1)
            pass
        elif self.lineEdit_Mode.text() == 'Spectrum':
            self.lineEdit_Mode.setText('Image')
            self.tabWidget.setCurrentIndex(0)
        pass

    def MVChangeResolution(self):
        height = int(self.lineEdit_ROIHeightPi.text())
        width = int(self.lineEdit_ROIWidthPi.text())
        heightOffset = int(self.lineEdit_ROIHeightOffsetPi.text())
        widthOffset = int(self.lineEdit_ROIWidthOffsetPi.text())

        # rect = QRect(widthOffset, heightOffset, width, height)
        # painter = QPainter(self.Viewer2)
        # painter.setPen(QPen(Qt.green, 2, Qt.SolidLine))
        # painter.drawRect(rect)

        reply = QMessageBox.question(self, '选择ROI', '确定应用？', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            PImageResolution = mvsdk.CameraGetResolutionForSnap(self.hCamera)
            PImageResolution.iIndex = 0xff
            PImageResolution.iWidth = (width)
            PImageResolution.iWidthFOV = (width)
            PImageResolution.iHeight = (height)
            PImageResolution.iHeightFOV = (height)
            PImageResolution.iHOffsetFOV = (widthOffset)
            PImageResolution.iVOffsetFOV = (heightOffset)
            mvsdk.CameraSetImageResolution(self.hCamera, PImageResolution)
            pass
        elif reply == QMessageBox.No:
            return
            pass
        pass

    def stop(self):
        global working
        if self.pushButton_Stop.text() == 'Stop':
            self.pushButton_Stop.setText('Continue')
            working = False

        elif self.pushButton_Stop.text() == 'Continue':
            self.pushButton_Stop.setText('Stop')
            working = True
            self.thread1.start()
            # self.Timer.start(1)
        pass

    def stopPi(self):
        global working2
        if self.pushButton_Stop_Pi.text() == 'Stop':
            self.pushButton_Stop_Pi.setText('Continue')
            working2 = False

        elif self.pushButton_Stop_Pi.text() == 'Continue':
            self.pushButton_Stop_Pi.setText('Stop')
            working2 = True
            self.thread2.start()
            # self.Timer.start(1)
        pass

    def SelectPath(self):
        defaultPath = r'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate'
        filename = QFileDialog.getExistingDirectory(self, 'Please select folder path', defaultPath)
        self.lineEdit_Path_Pi.setText(filename)
        pass

    def acquire2(self):
        global working
        working = False

        global working2
        working2 = False

        global autoAcqFlag
        autoAcqFlag = True

        global stopAutoAcqFlag
        stopAutoAcqFlag = False

        global focusingFlag
        focusingFlag = False
        self.currentframe = 0

        tt = self.Imgprocessor.LoadImageProcessParam()
        self.xLaserPosition = tt[0][0]
        self.yLaserPosition = tt[0][1]
        self.fittingSlope = tt[1][0]
        self.fittingIntercept = tt[1][1]
        self.fittingSlopeY = tt[2][0]
        self.fittingInterceptY = tt[2][1]

        # self.imageTracingFlag = True

        # self.Timer4.start(6000)  # 延时时间和ZWO相机的曝光时间有关系。预留给电机、舵机移动以及继电器的运动时间为 1.5x2 + 0.1 + 0.3 = 3.4s

        self.AcqNums = 0

        self.xPosition = []
        self.yPosition = []
        self.xPositionAbs = []
        self.yPositionAbs = []

        self.xPulse = []
        self.yPulse = []
        self.position_shift = [0, 0]
        self.sampleId = []
        self.area = []
        imgPath1 = 'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate\OriginalImage.jpg'
        self.img1 = cv2.cvtColor(cv2.imread(imgPath1), cv2.COLOR_RGB2GRAY)

        os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
        with open('Points need to be acquired.txt', 'r') as f:
            pulse = f.readline()
            while pulse:
                # print('data2:{}, type2:{}'.format(str2,type(str2)))
                x_tmp, y_tmp = [float(i) for i in pulse.split()]
                x_tmp = (x_tmp)
                y_tmp = (y_tmp)
                self.xPosition.append(x_tmp)
                self.yPosition.append(y_tmp)
                pulse = f.readline()
                pass
            pass
        with open('Points need to be acquired(abs).txt', 'r') as f:
            pulse = f.readline()
            while pulse:
                # print('data2:{}, type2:{}'.format(str2,type(str2)))
                x_tmp, y_tmp = [float(i) for i in pulse.split()]
                x_tmp = int(x_tmp)
                y_tmp = int(y_tmp)
                self.xPositionAbs.append(x_tmp)
                self.yPositionAbs.append(y_tmp)
                pulse = f.readline()
                pass
            pass
        with open('MotorPulse.txt', 'r') as f:
            pulse = f.readline()
            while pulse:
                x_tmp, y_tmp = [float(i) for i in pulse.split()]
                x_tmp = int(x_tmp)
                y_tmp = int(y_tmp)
                self.xPulse.append(x_tmp)
                self.yPulse.append(y_tmp)
                pulse = f.readline()
                pass
            pass

        with open('idd.txt', 'r') as f:
            idd = f.readline()
            while idd:
                self.sampleId.append(idd)
                idd = f.readline()
                pass
            pass

        with open('area.txt', 'r') as f:
            area = f.readline()
            while area:
                self.area.append(area)
                area = f.readline()
                pass
            pass

        self.xshift = 0
        self.yshift = 0

        # Block Laser
        self.Serialmovement.ServoMovement(self.ser, -1)
        time.sleep(0.51)
        # Turn on LED
        self.Serialmovement.changevoltage(self.ser, 1)
        time.sleep(0.1)

        self.Serialmovement.movement(self.ser, 'X Axis', self.yPulse[0])
        # print('yPulse is:{}'.format(self.yPulse[0]))
        time.sleep(3)
        self.Serialmovement.movement(self.ser, 'Y Axis', self.xPulse[0])
        time.sleep(3)


        # self.TotalNum = argument_[0]
        # self.hcamera = argument_[1]
        # self.camera = argument_[2]
        # self.Viewer = argument_[3]
        # self.Viewer2 = argument_[4]
        # self.ser = argument_[5]
        # self.curve = argument_[6]
        # self.lineEdit_CurrentFrame = argument_[7]
        # self.xPosition = argument_[8]
        # self.img1 = argument_[9]
        # self.xPositionAbs = argument_[10]
        # self.yPositionAbs = argument_[11]
        # self.xLaserPosition = argument_[12]
        # self.yLaserPosition = argument_[13]
        # self.fittingSlope = argument_[14]
        # self.fittingIntercept = argument_[15]
        # self.fittingSlopeY = argument_[16]
        # self.fittingInterceptY = argument_[17]
        # self.xPulse = argument_[18]
        # self.yPulse = argument_[19]
        # self.w = argument_[20]
        # self.h = argument_[21]
        # self.sleepPeriod = argument_[22]

        self.w = int(self.lineEdit_ROIWidthPi.text())
        self.h = int(self.lineEdit_ROIHeightPi.text())
        self.TotalNum = int(self.lineEdit_TotalNumbers.text())
        self.sleepPeriod = int(self.lineEdit_Exp.text()) / 1000000
        parameters = [self.TotalNum, self.hCamera, self.camera, self.Viewer, self.Viewer2, self.ser, self.curve,
                      self.lineEdit_CurrentFrame, self.xPosition, self.img1, self.xPositionAbs, self.yPositionAbs,
                      self.xLaserPosition, self.yLaserPosition, self.fittingSlope, self.fittingIntercept,
                      self.fittingSlopeY, self.fittingInterceptY, self.xPulse, self.yPulse, self.w, self.h,
                      self.sleepPeriod, self.sampleId, self.area]

# change thread to acquire beads or cells
        self.AutoAcqThread = AutoAcquisitionThread(parameters)
#         self.AutoAcqThread = AutoAcquisitionThread3(parameters)
        self.AutoAcqThread.start()
        self.AutoAcqThread._signal.connect(self.AutoFoucs)
        self.AutoAcqThread._RamanSignal.connect(self.showRamanSpec)

        pass

# for beads time series
    def acquire3(self):
        global working
        working = False

        global working2
        working2 = False

        global autoAcqFlag
        autoAcqFlag = True

        global stopAutoAcqFlag
        stopAutoAcqFlag = False

        global focusingFlag
        focusingFlag = False
        self.currentframe = 0

        tt = self.Imgprocessor.LoadImageProcessParam()
        self.xLaserPosition = tt[0][0]
        self.yLaserPosition = tt[0][1]
        self.fittingSlope = tt[1][0]
        self.fittingIntercept = tt[1][1]
        self.fittingSlopeY = tt[2][0]
        self.fittingInterceptY = tt[2][1]

        # self.imageTracingFlag = True

        # self.Timer4.start(6000)  # 延时时间和ZWO相机的曝光时间有关系。预留给电机、舵机移动以及继电器的运动时间为 1.5x2 + 0.1 + 0.3 = 3.4s

        self.AcqNums = 0

        self.xPosition = []
        self.yPosition = []
        self.xPositionAbs = []
        self.yPositionAbs = []

        self.xPulse = []
        self.yPulse = []
        self.position_shift = [0, 0]

        imgPath1 = 'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate\OriginalImage.jpg'
        self.img1 = cv2.cvtColor(cv2.imread(imgPath1), cv2.COLOR_RGB2GRAY)

        os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
        with open('Points need to be acquired.txt', 'r') as f:
            pulse = f.readline()
            while pulse:
                # print('data2:{}, type2:{}'.format(str2,type(str2)))
                x_tmp, y_tmp = [float(i) for i in pulse.split()]
                x_tmp = (x_tmp)
                y_tmp = (y_tmp)
                self.xPosition.append(x_tmp)
                self.yPosition.append(y_tmp)
                pulse = f.readline()
                pass
            pass
        with open('Points need to be acquired(abs).txt', 'r') as f:
            pulse = f.readline()
            while pulse:
                # print('data2:{}, type2:{}'.format(str2,type(str2)))
                x_tmp, y_tmp = [float(i) for i in pulse.split()]
                x_tmp = int(x_tmp)
                y_tmp = int(y_tmp)
                self.xPositionAbs.append(x_tmp)
                self.yPositionAbs.append(y_tmp)
                pulse = f.readline()
                pass
            pass
        with open('MotorPulse.txt', 'r') as f:
            pulse = f.readline()
            while pulse:
                x_tmp, y_tmp = [float(i) for i in pulse.split()]
                x_tmp = int(x_tmp)
                y_tmp = int(y_tmp)
                self.xPulse.append(x_tmp)
                self.yPulse.append(y_tmp)
                pulse = f.readline()
                pass
            pass



        self.xshift = 0
        self.yshift = 0

        timeSeriesT = self.lineEdit_TimeSeries.text()
        timeSeries = timeSeriesT.split(',')
        # Block Laser
        self.Serialmovement.ServoMovement(self.ser, -1)
        time.sleep(0.51)
        # Turn on LED
        self.Serialmovement.changevoltage(self.ser, 1)
        time.sleep(0.1)

        self.Serialmovement.movement(self.ser, 'X Axis', self.yPulse[0])
        # print('yPulse is:{}'.format(self.yPulse[0]))
        time.sleep(3)
        self.Serialmovement.movement(self.ser, 'Y Axis', self.xPulse[0])
        time.sleep(3)

        self.w = int(self.lineEdit_ROIWidthPi.text())
        self.h = int(self.lineEdit_ROIHeightPi.text())
        self.TotalNum = int(self.lineEdit_TotalNumbers.text())
        self.sleepPeriod = int(self.lineEdit_Exp.text()) / 1000000
        parameters = [self.TotalNum, self.hCamera, self.camera, self.Viewer, self.Viewer2, self.ser, self.curve,
                      self.lineEdit_CurrentFrame, self.xPosition, self.img1, self.xPositionAbs, self.yPositionAbs,
                      self.xLaserPosition, self.yLaserPosition, self.fittingSlope, self.fittingIntercept,
                      self.fittingSlopeY, self.fittingInterceptY, self.xPulse, self.yPulse, self.w, self.h, self.sleepPeriod, timeSeries]
        self.AutoAcqThread2 = AutoAcquisitionThread2(parameters)
        self.AutoAcqThread2.start()
        self.AutoAcqThread2._signal.connect(self.AutoFoucs)
        self.AutoAcqThread2._RamanSignal.connect(self.showRamanSpec2)
        pass

    def testPositioning(self):
        # if self.lineEdit_Path_Pi.text() == '':
        FolderPath = filedialog.askdirectory()
        self.lineEdit_Path_Pi.setText(FolderPath)
        os.chdir(FolderPath)
            # pass
        # else:
        #     FolderPath = self.lineEdit_Path_Pi.text()
        #     os.chdir(FolderPath)
        #     pass
        parameters = [self.hCamera, self.ser]
        self.TestPositioningThread = TestPositioning(parameters)
        self.TestPositioningThread.start()
        self.TestPositioningThread._signal.connect(self.AutoFoucs)
        global workingPositioning
        workingPositioning = True

        global focusingFlag
        focusingFlag = False
        pass

    def AutoFoucs(self):

        # global working2
        # working2 = False

        self.Brentemp = []
        self.focusFlag = True
        self.focusingFlag = True
        # self.ImgNums = 9
        # self.Steps = 40
        self.ImgNums = 11
        self.Steps = 40

        global steps_tuple
        steps_tuple = (self.ImgNums) * [self.Steps]
        # steps_tuple[0] = int(-self.Steps * ((self.ImgNums+1)/2))
        steps_tuple[0] = -180

        # self.Serialmovement.movement(self.ser, 'Z Axis', steps_tuple[0])
        # time.sleep(1.5)
        global numflag
        numflag = 0
        global exitFlag
        exitFlag = True

        # self.Bren = []
        # self.BrenFore = []
        # self.BrenBack = []
        self.AutoFoThread = AutoFocusThread([self.hCamera, self.ser, self.LineFigure,
                                             self.ImgNums, self.Steps, self.thread2])

        # self.AutoFoThread._signal.connect(self.DispImg2)
        self.AutoFoThread.start()

        pass

    def showRamanSpec(self, sp):

        self.curve.setData(sp)
        curr_time = datetime.datetime.now()
        time_str = datetime.datetime.strftime(curr_time, '%Y_%m_%d_%H_%M_%S')

        filename = str(time_str) + '.txt'
        os.chdir(
            'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\RamanSpectra')
        np.savetxt(filename, sp)
        self.currentframe += 1
        self.lineEdit_CurrentFrame.setText(str(self.currentframe))

        pass

    def showRamanSpec2(self, sp):

        self.curve.setData(sp)
        # curr_time = datetime.datetime.now()
        # time_str = datetime.datetime.strftime(curr_time, '%Y_%m_%d_%H_%M_%S')
        #
        # filename = str(time_str) + '.txt'
        # os.chdir(
        #     'D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\RamanSpectra')
        # np.savetxt(filename, sp)
        self.currentframe += 1
        self.lineEdit_CurrentFrame.setText(str(self.currentframe))

        pass

    def changeAutoAcqFlag(self):
        global autoAcqFlag
        global stopAutoAcqFlag
        if self.sender() == self.pushButton_QuitAcq:
            autoAcqFlag = False
            pass

        elif self.sender() == self.pushButton_StopAcq:
            if self.pushButton_StopAcq.text() == 'Stop Acquisition':
                self.pushButton_StopAcq.setText('Continue Acquisition')
                stopAutoAcqFlag = True
                pass
            elif self.pushButton_StopAcq.text() == 'Continue Acquisition':
                self.pushButton_StopAcq.setText('Stop Acquisition')
                stopAutoAcqFlag = False
                pass
            pass

        pass

    def ChangeTimeInterval(self):
        global timeInter1
        global timeInter2
        if timeInter2 == 2:
            timeInter1 = 0.2
            timeInter2 = 0.2
            pass

        else:
            timeInter1 = 1
            timeInter2 = 2
            pass

        pass

    def moveForward(self):
        steps = abs(int(self.lineEdit_Step.text()))
        axis_temp = self.comboBox_Axis.currentText()
        # print(self.ser, axis_temp, steps)
        self.Serialmovement.movement(self.ser, axis_temp, steps)
        pass

    def moveBackward(self):
        steps = -(int(self.lineEdit_Step.text()))
        # print(type(steps), steps)
        axis_temp = self.comboBox_Axis.currentText()
        self.Serialmovement.movement(self.ser, axis_temp, steps)
        pass

    def ServoMovement(self):
        if self.sender() == self.pushButton_LaserIn:
            self.Serialmovement.ServoMovement(self.ser, 1)
            pass
        elif self.sender() == self.pushButton_LaserOut:
            self.Serialmovement.ServoMovement(self.ser, -1)
            pass
        pass

    def movement(self, steps, axis_temp):
        self.Serialmovement.movement(self.ser, axis_temp, steps)
        pass

    def changevoltage(self):

        if self.sender() == self.pushButton_TurnOn:
            self.Serialmovement.changevoltage(self.ser, 1)
            pass

        elif self.sender() == self.pushButton_TurnOff:
            self.Serialmovement.changevoltage(self.ser, -1)
            pass

        pass

    def serialInit(self):
        serialName = self.comboBox_SerialPort.currentText()
        if serialName == 'Arduino Uno (COM3)':
            serialName = 'COM3'
            pass
        self.ser = serial.Serial(serialName, 9600, timeout = 3)
        self.serialFlag = 1
        pass

    def serialClose(self):
        self.ser.close()
        pass

    def Quit(self):
        self.Timer.stop()
        asi._close_camera(self.camera_id)
        mvsdk.CameraUnInit(self.hCamera)
        if self.serialFlag == 1:
            self.serialClose()
            pass
        self.close()
        pass

    def closeEvent(self, event):
        reply = QMessageBox.question(self, '确认', '确认退出吗', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            # asi._close_camera(self.camera_id)
            self.Quit()
            event.accept()
            pass
        else:
            event.ignore()
            pass
        pass

    pass

def unevenLightCompensate(img, blockSize, min_num,max_num):
    gray = img
    average = np.mean(gray)

    rows_new = int(np.ceil(gray.shape[0] / blockSize))
    cols_new = int(np.ceil(gray.shape[1] / blockSize))

    blockImage = np.zeros((rows_new, cols_new), dtype=np.float32)
    for r in range(rows_new):
        for c in range(cols_new):
            rowmin = r * blockSize
            rowmax = (r + 1) * blockSize
            if (rowmax > gray.shape[0]):
                rowmax = gray.shape[0]
            colmin = c * blockSize
            colmax = (c + 1) * blockSize
            if (colmax > gray.shape[1]):
                colmax = gray.shape[1]

            imageROI = gray[rowmin:rowmax, colmin:colmax]
            temaver = np.mean(imageROI)
            blockImage[r, c] = temaver
    blockImage = blockImage - average
    blockImage2 = cv2.resize(blockImage, (gray.shape[1], gray.shape[0]), interpolation=cv2.INTER_CUBIC)
    # blockImage2[200:800,200:500]=0
    gray2 = gray.astype(np.float32)
    dst = gray2 - blockImage2
    for i in range(len(dst)):
        for j in range(len(dst[0])):
            if dst[i][j]<min_num:
                dst[i][j]=min_num
            elif dst[i][j]>max_num:
                dst[i][j]=max_num
    dst = dst.astype(np.uint8)
    dst = cv2.GaussianBlur(dst, (3, 3), 0)
    return dst

def gamma_trans(img,gamma):
    #具体做法先归一化到1，然后gamma作为指数值求出新的像素值再还原
    gamma_table = [np.power(x/255.0,gamma)*255.0 for x in range(256)]
    gamma_table = np.round(np.array(gamma_table)).astype(np.uint8)
    #实现映射用的是Opencv的查表函数
    return cv2.LUT(img,gamma_table)

def GetMVFrame(hCamera):

    # 相机模式切换成连续采集
    # mvsdk.CameraSetTriggerMode(hCamera, 0)

    cap = mvsdk.CameraGetCapability(hCamera)
    # 计算RGB buffer所需的大小，这里直接按照相机的最大分辨率来分配
    FrameBufferSize = cap.sResolutionRange.iWidthMax * cap.sResolutionRange.iHeightMax * 1

    # 分配RGB buffer，用来存放ISP输出的图像
    # 备注：从相机传输到PC端的是RAW数据，在PC端通过软件ISP转为RGB数据（如果是黑白相机就不需要转换格式，但是ISP还有其它处理，所以也需要分配这个buffer）
    pFrameBuffer = mvsdk.CameraAlignMalloc(FrameBufferSize, 16)

    pRawData, FrameHead = mvsdk.CameraGetImageBuffer(hCamera, 200)
    mvsdk.CameraImageProcess(hCamera, pRawData, pFrameBuffer, FrameHead)
    mvsdk.CameraReleaseImageBuffer(hCamera, pRawData)

    # windows下取到的图像数据是上下颠倒的，以BMP格式存放。转换成opencv则需要上下翻转成正的
    # linux下直接输出正的，不需要上下翻转
    if platform.system() == "Windows":
        mvsdk.CameraFlipFrameBuffer(pFrameBuffer, FrameHead, 1)

    # 此时图片已经存储在pFrameBuffer中，对于彩色相机pFrameBuffer=RGB数据，黑白相机pFrameBuffer=8位灰度数据
    # 把pFrameBuffer转换成opencv的图像格式以进行后续算法处理
    frame_data = (mvsdk.c_ubyte * FrameHead.uBytes).from_address(pFrameBuffer)
    frame = np.frombuffer(frame_data, dtype=np.uint8)

    frame = frame.reshape((FrameHead.iHeight, FrameHead.iWidth))
    # mvsdk.CameraAlignFree(pFrameBuffer)

    return frame


class Figure_Canvas(FigureCanvas):

    def __init__(self, parent = None, width = 8, height = 6, dpi = 100):
        # 创建一个Figure
        self.fig = Figure( figsize=(width, height), dpi = 100)
        # 在父类中激活Figure窗口,该句是必须要存在的，否则不能正常的显示图形
        super(Figure_Canvas, self).__init__(self.fig)
        # 创建一个子图，用于绘制图形用，111表示子图编号
        self.ax = self.fig.add_subplot(111)
        pass

    def test(self):
        x = [1, 2, 3, 4, 5, 6, 7]
        y = [2, 1, 3, 5, 6, 4, 3]
        self.ax.plot(x, y)
        pass

    def plotfitting(self,x,y,xfitting, yfitting):
        self.ax.scatter(x,y)
        self.ax.plot(xfitting, yfitting)
    pass

# 目前没有使用到，后期修改程序加入以实现在显示图片的时候能够在图片上直接拖拽出矩形框，
# 以便于我们直接在图像上选出感兴趣的区域
class Mylabel(QLabel):
    x0 = 0
    y0 = 0
    x1 = 0
    y1 = 0
    mousemoveflag = False

    def mousePressEvent(self, event):
        self.mousemoveflag = True
        self.x0 = event.x()
        self.y0 = event.y()
        pass

    def mouseReleaseEvent(self, event):
        self.mousemoveflag = False
        pass

    def mouseMoveEvent(self, event):
        if self.flag:
            self.x1 = event.x()
            self.y1 = event.y()
            self.update()
        pass

    pass

class SerialPort():
    position = ""
    def movement(self, ser, axis_temp, steps):
        if axis_temp == 'X Axis':
            axis = '0'
            pass
        elif axis_temp == 'Y Axis':
            axis = '1'
            pass
        elif axis_temp == 'Z Axis':
            axis = '2'
            pass

        if steps > 0:
            self.position = axis + ',0,' + str(int(steps)) + ',20'  ##输入电机号及应走的步数，如“x-500”表示x轴电机走-500步
            pass
        elif steps < 0:
            self.position = axis + ',1,' + str(abs(int(steps))) + ',20'  ##输入电机号及应走的步数，如“x-500”表示x轴电机走-500步
            pass
        print(self.position)
        ser.write(self.position.encode('utf - 8'))
        pass

    def ServoMovement(self, ser, dir):
        if dir > 0:
            # (laser in)
            self.position = '3' + ',1' + ',5'
            ser.write(self.position.encode('utf - 8'))
            pass
        elif dir < 0:
            # (laser out)
            self.position = '3' + ',1' + ',1'
            ser.write(self.position.encode('utf - 8'))
            pass
        # print(self.position)
        pass

    def changevoltage(self, ser, dir):
        if dir > 0:
            # turn on LED
            voltage = '4' + ',0'
            ser.write(voltage.encode('utf - 8'))
            pass

        elif dir < 0:
            # turn off LED
            voltage = '4' + ',1'
            ser.write(voltage.encode('utf - 8'))
            pass
        # print(voltage)
        pass

    pass

class ImgProcess():

    def imgSegment(self, img, Thres, Kshape, Ksize, distance, w, h):
        tt = self.LoadImageProcessParam()
        xLaserPosition = tt[0][0]
        yLaserPosition = tt[0][1]
        fittingSlope = tt[1][0]
        fittingIntercept = tt[1][1]
        fittingSlopeY = tt[2][0]
        fittingInterceptY = tt[2][1]

        _, thresh = cv2.threshold(img, Thres, 255, cv2.THRESH_BINARY)
        kernel = cv2.getStructuringElement(Kshape, Ksize)  # 定义矩形结构元素
        opening = cv2.morphologyEx(thresh, cv2.MORPH_GRADIENT, kernel)  # 梯度

        # Finding sure foreground area
        dist_transform = cv2.distanceTransform(opening, cv2.DIST_L2, 5)
        ret, sure_fg = cv2.threshold(dist_transform, distance * dist_transform.max(), 255, 0)
        sure_fg = np.uint8(sure_fg)

        _, contours, hirearchy = cv2.findContours(sure_fg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)  # 找出连通域
        area = []  # 建立空数组，放连通域面积
        contours1 = []  # 建立空数组，放减去最小面积的数
        for i in contours:
            if cv2.contourArea(i) > 5:  # 计算面积 去除面积小的 连通域
                contours1.append(i)
                area.append(cv2.contourArea(i))
                pass
            pass

        if len(contours1):
            draw = cv2.drawContours(img, contours1, -1, (0, 255, 0), 2)  # 描绘连通域求连通域重心 以及 在重心坐标点描绘数字
            grayCenter = []
            for i, j in zip(contours1, range(len(contours1))):
                M = cv2.moments(i)
                cX = (M["m10"] / M["m00"])
                cY = (M["m01"] / M["m00"])
                grayCenter.append([cX, cY])

                cX1 = int(cX)
                cY1 = int(cY)
                draw1 = cv2.putText(draw, str(j), (cX1, cY1), 1, 1, (255, 0, 255), 1)  # 在中心坐标点上描绘数字展示图片
                pass
            # cv2.namedWindow("Gray center", cv2.WINDOW_NORMAL)
            # cv2.imshow("Gray center", draw1)
            # cv2.waitKey()
            # cv2.destroyAllWindows()

            filename = 'Points need to be acquired' + '.txt'
            position = []
            position1 = []
            positionPart = []
            os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
            # position1 = grayCenter
            idd = []
            idd_flag = 0
            area1 = []
            for x in (grayCenter):
                # w = int(self.lineEdit_ROIWidthPi.text())
                # h = int(self.lineEdit_ROIHeightPi.text())
                dx = w - x[0]
                dy = h - x[1]
                # print('dx and dy are:{}'.format((dx, dy)))
                # if (x[0] - xLaserPosition) >= -20 and x[1] - yLaserPosition <= 10 and dx > 30 and dy > 30:
                if x[0] >= 30 and x[1] >= 30 and dx > 30 and dy > 30:
                    position1.append(x)
                    idd.append(idd_flag)
                    area1.append(area[idd_flag])
                    pass
                idd_flag += 1
                pass
            print("position1 is :{}".format(position1))
            np.savetxt('idd.txt', idd)
            np.savetxt('area.txt', area1)

            if len(position1) <= 10 and len(position1) >= 1:
                position.append(position1[0])
                for i in range(1, len(position1)):
                    temp = position1[i - 1]
                    x = position1[i]
                    position.append([temp[0] - x[0], temp[1] - x[1]])
                    pass
                os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
                np.savetxt(filename, position)
                np.savetxt('Points need to be acquired(abs).txt', position1)
                pass
            elif len(position1) == 0:
                position = []
                position1 = []
                filename = 'Points need to be acquired' + '.txt'
                os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
                np.savetxt(filename, position)
                np.savetxt('Points need to be acquired(abs).txt', position1)
                pass

            else:
                points = '0,1,2,3,4,5,6,7,8,9'
                point_list = points.split(',')
                for i in point_list:
                    positionPart.append(position1[int(i)])
                    pass
                position.append(positionPart[0])
                for i in range(1, len(positionPart)):
                    # print('i is :{}'.format(i))
                    temp = positionPart[i - 1]
                    # print('temp is :{}'.format(temp))
                    x = positionPart[i]
                    # print('x is :{}'.format(x))
                    position.append([temp[0] - x[0], temp[1] - x[1]])
                    pass
                pass
                os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
                np.savetxt(filename, position)
                np.savetxt('Points need to be acquired(abs).txt', positionPart)
            pass

        else:
            position = []
            filename = 'Points need to be acquired' + '.txt'
            os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
            np.savetxt(filename, position)
            np.savetxt('Points need to be acquired(abs).txt', position)
            pass

        motorPulse = []
        timeflag = 0
        with open('Points need to be acquired.txt', 'r') as f:
            position = f.readline()
            while position:
                x_tmp, y_tmp = [float(i) for i in position.split()]
                if timeflag == 0:
                    Diff_temp = [-(x_tmp - xLaserPosition), -(y_tmp - yLaserPosition)]
                else:
                    Diff_temp = [x_tmp, y_tmp]
                    pass
                timeflag += 1
                positionDiff = [int(Diff_temp[0] * fittingSlopeY + fittingInterceptY),
                                int(Diff_temp[1] * fittingSlope + fittingIntercept)]

                motorPulse.append(positionDiff)
                position = f.readline()
                pass
            # print(motorPulse)
            pass
        os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
        np.savetxt('MotorPulse.txt', motorPulse)
        pass

    def imgSegment2(self, img, Thres, Kshape, Ksize, distance, w, h):
        tt = self.LoadImageProcessParam()
        xLaserPosition = tt[0][0]
        yLaserPosition = tt[0][1]
        fittingSlope = tt[1][0]
        fittingIntercept = tt[1][1]
        fittingSlopeY = tt[2][0]
        fittingInterceptY = tt[2][1]

        # _, thresh = cv2.threshold(img, Thres, 255, cv2.THRESH_BINARY)

        # gradX = cv2.Sobel(img, ddepth=cv2.CV_32F, dx=1, dy=0)
        # gradY = cv2.Sobel(img, ddepth=cv2.CV_32F, dx=0, dy=1)
        # gradient = cv2.subtract(gradX, gradY)
        # gradient = cv2.convertScaleAbs(gradient)  # 转换位深
        # blurred = cv2.GaussianBlur(gradient, (3, 3), 0)
        # _, thresh = (cv2.threshold(blurred, Thres, 255, cv2.THRESH_BINARY))
        # # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (10, 10))
        # # closed = cv2.morphologyEx(thresh, cv2.MORPH_ELLIPSE, kernel)
        # # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        # # closed = cv2.erode(closed, kernel, iterations = 2)
        # # thresh = closed

        edges = cv2.Canny(img, Thres, 250, L2gradient=False)
        # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13))  # 定义结构元素的形状和大小
        # thresh = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)
        thresh = edges

        kernel = cv2.getStructuringElement(Kshape, Ksize)  # 定义矩形结构元素
        opening = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)  # 梯度

        # Finding sure foreground area
        dist_transform = cv2.distanceTransform(opening, cv2.DIST_L2, 5)
        ret, sure_fg = cv2.threshold(dist_transform, distance * dist_transform.max(), 255, 0)
        sure_fg = np.uint8(sure_fg)

        _, contours, hirearchy = cv2.findContours(sure_fg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)  # 找出连通域
        area = []  # 建立空数组，放连通域面积
        contours1 = []  # 建立空数组，放减去最小面积的数
        for i in contours:
            if cv2.contourArea(i) > 50:  # 计算面积 去除面积小的 连通域
                contours1.append(i)
                pass
            pass

        if len(contours1):
            draw = cv2.drawContours(img, contours1, -1, (0, 255, 0), 2)  # 描绘连通域求连通域重心 以及 在重心坐标点描绘数字
            grayCenter = []
            for i, j in zip(contours1, range(len(contours1))):
                M = cv2.moments(i)
                cX = (M["m10"] / M["m00"])
                cY = (M["m01"] / M["m00"])
                grayCenter.append([cX, cY])

                cX1 = int(cX)
                cY1 = int(cY)
                draw1 = cv2.putText(draw, str(j), (cX1, cY1), 1, 1, (255, 0, 255), 1)  # 在中心坐标点上描绘数字展示图片
                pass
            # cv2.namedWindow("Gray center", cv2.WINDOW_NORMAL)
            # cv2.imshow("Gray center", draw1)
            # cv2.waitKey()
            # cv2.destroyAllWindows()

            filename = 'Points need to be acquired' + '.txt'
            position = []
            position1 = []
            positionPart = []
            os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
            # position1 = grayCenter
            for x in (grayCenter):
                # w = int(self.lineEdit_ROIWidthPi.text())
                # h = int(self.lineEdit_ROIHeightPi.text())
                dx = w - x[0]
                dy = h - x[1]
                # print('dx and dy are:{}'.format((dx, dy)))
                # if (x[0] - xLaserPosition) >= -20 and x[1] - yLaserPosition <= 10 and dx > 30 and dy > 30:
                if x[0] >= 30 and x[1] >= 30 and dx > 30 and dy > 30:
                    position1.append(x)
                    pass
                pass
            print("position1 is :{}".format(position1))

            if len(position1) <= 10 and len(position1) >= 1:
                position.append(position1[0])
                for i in range(1, len(position1)):
                    temp = position1[i - 1]
                    x = position1[i]
                    position.append([temp[0] - x[0], temp[1] - x[1]])
                    pass
                os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
                np.savetxt(filename, position)
                np.savetxt('Points need to be acquired(abs).txt', position1)
                pass
            elif len(position1) == 0:
                position = []
                position1 = []
                filename = 'Points need to be acquired' + '.txt'
                os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
                np.savetxt(filename, position)
                np.savetxt('Points need to be acquired(abs).txt', position1)
                pass
            else:
                points = '0,1,2,3,4,5,6,7,8,9'
                point_list = points.split(',')
                for i in point_list:
                    positionPart.append(position1[int(i)])
                    pass
                position.append(positionPart[0])
                for i in range(1, len(positionPart)):
                    # print('i is :{}'.format(i))
                    temp = positionPart[i - 1]
                    # print('temp is :{}'.format(temp))
                    x = positionPart[i]
                    # print('x is :{}'.format(x))
                    position.append([temp[0] - x[0], temp[1] - x[1]])
                    pass
                pass
                os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
                np.savetxt(filename, position)
                np.savetxt('Points need to be acquired(abs).txt', positionPart)
            pass

        else:
            position = []
            filename = 'Points need to be acquired' + '.txt'
            os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
            np.savetxt(filename, position)
            np.savetxt('Points need to be acquired(abs).txt', position)
            pass

        motorPulse = []
        timeflag = 0
        with open('Points need to be acquired.txt', 'r') as f:
            position = f.readline()
            while position:
                x_tmp, y_tmp = [float(i) for i in position.split()]
                if timeflag == 0:
                    Diff_temp = [-(x_tmp - xLaserPosition), -(y_tmp - yLaserPosition)]
                else:
                    Diff_temp = [x_tmp, y_tmp]
                    pass
                timeflag += 1
                positionDiff = [int(Diff_temp[0] * fittingSlopeY + fittingInterceptY),
                                int(Diff_temp[1] * fittingSlope + fittingIntercept)]

                motorPulse.append(positionDiff)
                position = f.readline()
                pass
            # print(motorPulse)
            pass
        os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\coordinate')
        np.savetxt('MotorPulse.txt', motorPulse)
        pass

    def imagecompare(self, img1, img2, centerposition, centerposition2):

        img1_corrted = unevenLightCompensate(img1, 36, 0, 255)
        img1 = gamma_trans(img1_corrted, 1.35)

        img2_corrted = unevenLightCompensate(img2, 36, 0, 255)
        img2 = gamma_trans(img2_corrted, 1.35)

        position_shift = []
        x = centerposition[0]
        y = centerposition[1]

        # lfxposInsrc, lfyposInsrc = x - 10, y - 14
        # rixposInsrc, riyposInsrc = x + 10, y + 14

        lfxposInsrc, lfyposInsrc = x - 16, y - 20
        rixposInsrc, riyposInsrc = x + 16, y + 20
        tplImg = img1[lfyposInsrc:riyposInsrc, lfxposInsrc:rixposInsrc]

        x2 = centerposition2[0]
        y2 = centerposition2[1]

        # lfxposIntar, lfyposIntar = x2 - 28, y2 - 28
        # rixposIntar, riyposIntar = x2 + 28, y2 + 28
        lfxposIntar, lfyposIntar = x2 - 32, y2 - 32
        rixposIntar, riyposIntar = x2 + 32, y2 + 32
        targetImg = img2[lfyposIntar:riyposIntar, lfxposIntar:rixposIntar]

        # print(lfyposIntar, riyposIntar, lfxposIntar, rixposIntar)

        md = cv2.TM_SQDIFF_NORMED
        th, tw = tplImg.shape[:2]
        result = cv2.matchTemplate(targetImg, tplImg, md)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
        if md == cv2.TM_SQDIFF_NORMED:
            tl = min_loc
        else:
            tl = max_loc
        br = (tl[0] + tw, tl[1] + th)
        targetImg_copy = targetImg.copy()
        img1_copy = img1.copy()

        # cv2.rectangle(targetImg_copy, tl, br, [0, 0, 0])
        # cv2.namedWindow('TargetImage', cv2.WINDOW_NORMAL)
        # cv2.resizeWindow('TargetImage', 480, 360)
        # cv2.imshow("TargetImage", targetImg_copy)
        # #
        # cv2.rectangle(img1_copy, (lfxposInsrc, lfyposInsrc), (rixposInsrc, riyposInsrc), (0, 255, 0), 3)
        # cv2.namedWindow('img1', cv2.WINDOW_NORMAL)
        # cv2.resizeWindow('img1', 480, 360)
        # cv2.imshow('img1', img1_copy)
        # cv2.waitKey()
        # cv2.destroyAllWindows()

        position_shift.append(lfxposIntar + tl[0] - lfxposInsrc)
        position_shift.append(lfyposIntar + tl[1] - lfyposInsrc)
        # print('tl is:{}'.format(tl))
        # print('source position is:{}'.format([lfxposInsrc, lfyposInsrc]))
        # print('position shift is:{}'.format(position_shift))
        return position_shift

    def LoadImageProcessParam(self):
        os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\LaserCalibration')
        with open('LaserPosition.txt', 'r') as f:
            laserPosition = f.readlines()
            xLaserPosition, = (float(i) for i in laserPosition[0].split())
            yLaserPosition, = (float(i) for i in laserPosition[1].split())
            # self.lineEdit_XLaser.setText(str(self.xLaserPosition))
            # self.lineEdit_YLaser.setText(str(self.yLaserPosition))
            pass

        os.chdir('D:\Wangxianli\Graduation project\Low-cost Raman\Code\Python\Program running cache\MotorCalibration')
        with open('Relationship between pulse and Image length.txt', 'r') as f:
            fittingResult = f.readlines()
            fittingSlope, = (float(i) for i in fittingResult[0].split())
            fittingIntercept, = (float(i) for i in fittingResult[1].split())
            pass

        with open('Relationship between pulse and Image length Y.txt') as f:
            fittingResult = f.readlines()
            fittingSlopeY, = (float(i) for i in fittingResult[0].split())
            fittingInterceptY, = (float(i) for i in fittingResult[1].split())
            pass
        return [[xLaserPosition, yLaserPosition], [fittingSlope, fittingIntercept], [fittingSlopeY, fittingInterceptY]]

    pass



if __name__ == '__main__':
    app = QApplication(sys.argv)
    action = Action()
    sys.exit(app.exec_())
    pass
